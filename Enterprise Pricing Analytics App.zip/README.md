
  # Enterprise Pricing Analytics App

  This is a code bundle for Enterprise Pricing Analytics App. The original project is available at https://www.figma.com/design/T377HxJuY6txK0uClKlzRm/Enterprise-Pricing-Analytics-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  