import { Hono } from "npm:hono@4";
import { cors } from "npm:hono@4/cors";
import { logger } from "npm:hono@4/logger";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
    credentials: true,
  }),
);

// Health check endpoint
app.get("/make-server-acb28b15/health", (c) => {
  return c.json({ status: "ok" });
});

// ============== Product Hierarchy ==============
app.get("/make-server-acb28b15/product-hierarchies", async (c) => {
  try {
    const items = await kv.getByPrefix("product_hierarchy:");
    return c.json({ success: true, data: items });
  } catch (error) {
    console.log("Error fetching product hierarchies:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

app.post("/make-server-acb28b15/product-hierarchies/import", async (c) => {
  try {
    const { data } = await c.req.json();
    // data should be array of { id, name, description }
    for (const item of data) {
      await kv.set(`product_hierarchy:${item.id}`, item);
    }
    return c.json({ success: true, count: data.length });
  } catch (error) {
    console.log("Error importing product hierarchies:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// ============== Customers ==============
app.get("/make-server-acb28b15/customers", async (c) => {
  try {
    const items = await kv.getByPrefix("customer:");
    return c.json({ success: true, data: items });
  } catch (error) {
    console.log("Error fetching customers:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

app.post("/make-server-acb28b15/customers/import", async (c) => {
  try {
    const { data } = await c.req.json();
    // data should be array of { id, name, type, region, country }
    for (const item of data) {
      await kv.set(`customer:${item.id}`, item);
    }
    return c.json({ success: true, count: data.length });
  } catch (error) {
    console.log("Error importing customers:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// ============== Sales Organizations ==============
app.get("/make-server-acb28b15/sales-orgs", async (c) => {
  try {
    const items = await kv.getByPrefix("sales_org:");
    return c.json({ success: true, data: items });
  } catch (error) {
    console.log("Error fetching sales orgs:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

app.post("/make-server-acb28b15/sales-orgs/import", async (c) => {
  try {
    const { data } = await c.req.json();
    // data should be array of { id, name, region }
    for (const item of data) {
      await kv.set(`sales_org:${item.id}`, item);
    }
    return c.json({ success: true, count: data.length });
  } catch (error) {
    console.log("Error importing sales orgs:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// ============== Regions ==============
app.get("/make-server-acb28b15/regions", async (c) => {
  try {
    const items = await kv.getByPrefix("region:");
    return c.json({ success: true, data: items });
  } catch (error) {
    console.log("Error fetching regions:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

app.post("/make-server-acb28b15/regions/import", async (c) => {
  try {
    const { data } = await c.req.json();
    // data should be array of { id, name }
    for (const item of data) {
      await kv.set(`region:${item.id}`, item);
    }
    return c.json({ success: true, count: data.length });
  } catch (error) {
    console.log("Error importing regions:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// ============== Countries ==============
app.get("/make-server-acb28b15/countries", async (c) => {
  try {
    const items = await kv.getByPrefix("country:");
    return c.json({ success: true, data: items });
  } catch (error) {
    console.log("Error fetching countries:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

app.post("/make-server-acb28b15/countries/import", async (c) => {
  try {
    const { data } = await c.req.json();
    // data should be array of { id, name, code, region }
    for (const item of data) {
      await kv.set(`country:${item.id}`, item);
    }
    return c.json({ success: true, count: data.length });
  } catch (error) {
    console.log("Error importing countries:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// ============== Currencies ==============
app.get("/make-server-acb28b15/currencies", async (c) => {
  try {
    const items = await kv.getByPrefix("currency:");
    return c.json({ success: true, data: items });
  } catch (error) {
    console.log("Error fetching currencies:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

app.post("/make-server-acb28b15/currencies/import", async (c) => {
  try {
    const { data } = await c.req.json();
    // data should be array of { id, code, name, symbol }
    for (const item of data) {
      await kv.set(`currency:${item.id}`, item);
    }
    return c.json({ success: true, count: data.length });
  } catch (error) {
    console.log("Error importing currencies:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// ============== Price Lists ==============
app.get("/make-server-acb28b15/price-lists", async (c) => {
  try {
    const items = await kv.getByPrefix("price_list:");
    return c.json({ success: true, data: items });
  } catch (error) {
    console.log("Error fetching price lists:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

app.post("/make-server-acb28b15/price-lists/import", async (c) => {
  try {
    const { data } = await c.req.json();
    // data should be array of { id, name, type, validFrom, validTo }
    for (const item of data) {
      await kv.set(`price_list:${item.id}`, item);
    }
    return c.json({ success: true, count: data.length });
  } catch (error) {
    console.log("Error importing price lists:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// ============== Payment Terms ==============
app.get("/make-server-acb28b15/payment-terms", async (c) => {
  try {
    const items = await kv.getByPrefix("payment_terms:");
    return c.json({ success: true, data: items });
  } catch (error) {
    console.log("Error fetching payment terms:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

app.post("/make-server-acb28b15/payment-terms/import", async (c) => {
  try {
    const { data } = await c.req.json();
    // data should be array of { id, name, days, description }
    for (const item of data) {
      await kv.set(`payment_terms:${item.id}`, item);
    }
    return c.json({ success: true, count: data.length });
  } catch (error) {
    console.log("Error importing payment terms:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// ============== Products ==============
app.get("/make-server-acb28b15/products", async (c) => {
  try {
    const items = await kv.getByPrefix("product:");
    return c.json({ success: true, data: items });
  } catch (error) {
    console.log("Error fetching products:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

app.post("/make-server-acb28b15/products/import", async (c) => {
  try {
    const { data } = await c.req.json();
    // data should be array of { id, sku, productName, listPrice, cost, category, description }
    for (const item of data) {
      await kv.set(`product:${item.id}`, item);
    }
    return c.json({ success: true, count: data.length });
  } catch (error) {
    console.log("Error importing products:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

app.delete("/make-server-acb28b15/products/:id", async (c) => {
  try {
    const id = c.req.param("id");
    await kv.del(`product:${id}`);
    return c.json({ success: true });
  } catch (error) {
    console.log("Error deleting product:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// ============== Quotes ==============
app.get("/make-server-acb28b15/quotes", async (c) => {
  try {
    const items = await kv.getByPrefix("quote:");
    // Sort by date created (descending)
    const sorted = items.sort((a: any, b: any) => {
      return new Date(b.dateCreated).getTime() - new Date(a.dateCreated).getTime();
    });
    return c.json({ success: true, data: sorted });
  } catch (error) {
    console.log("Error fetching quotes:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

app.get("/make-server-acb28b15/quotes/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const quote = await kv.get(`quote:${id}`);
    return c.json({ success: true, data: quote });
  } catch (error) {
    console.log("Error fetching quote:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

app.post("/make-server-acb28b15/quotes", async (c) => {
  try {
    const quote = await c.req.json();
    const quoteId = quote.id || `Q-${Date.now()}`;
    const quoteData = {
      ...quote,
      id: quoteId,
      dateCreated: quote.dateCreated || new Date().toISOString(),
      dateModified: new Date().toISOString(),
    };
    await kv.set(`quote:${quoteId}`, quoteData);
    return c.json({ success: true, data: quoteData });
  } catch (error) {
    console.log("Error saving quote:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

app.put("/make-server-acb28b15/quotes/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const quote = await c.req.json();
    const quoteData = {
      ...quote,
      id,
      dateModified: new Date().toISOString(),
    };
    await kv.set(`quote:${id}`, quoteData);
    return c.json({ success: true, data: quoteData });
  } catch (error) {
    console.log("Error updating quote:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

app.delete("/make-server-acb28b15/quotes/:id", async (c) => {
  try {
    const id = c.req.param("id");
    await kv.del(`quote:${id}`);
    return c.json({ success: true });
  } catch (error) {
    console.log("Error deleting quote:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// ============== Line Item Configuration ==============
app.get("/make-server-acb28b15/config/line-item-fields", async (c) => {
  try {
    const config = await kv.get("config:line_item_fields");
    return c.json({ success: true, data: config });
  } catch (error) {
    console.log("Error fetching line item config:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

app.post("/make-server-acb28b15/config/line-item-fields", async (c) => {
  try {
    const { fields } = await c.req.json();
    await kv.set("config:line_item_fields", fields);
    return c.json({ success: true });
  } catch (error) {
    console.log("Error saving line item config:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// ============== Header Fields Configuration ==============
app.get("/make-server-acb28b15/config/header-fields", async (c) => {
  try {
    const config = await kv.get("config:header_fields");
    return c.json({ success: true, data: config });
  } catch (error) {
    console.log("Error fetching header fields config:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

app.post("/make-server-acb28b15/config/header-fields", async (c) => {
  try {
    const { fields } = await c.req.json();
    await kv.set("config:header_fields", fields);
    return c.json({ success: true });
  } catch (error) {
    console.log("Error saving header fields config:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// ============== AI Pricing Engine ==============
app.get("/make-server-acb28b15/ai-pricing/check-api-key", async (c) => {
  try {
    const apiKey = await kv.get("config:openai_api_key");
    return c.json({ hasApiKey: !!apiKey });
  } catch (error) {
    console.log("Error checking API key:", error);
    return c.json({ hasApiKey: false }, 500);
  }
});

app.post("/make-server-acb28b15/ai-pricing/set-api-key", async (c) => {
  try {
    const { apiKey } = await c.req.json();
    await kv.set("config:openai_api_key", apiKey);
    return c.json({ success: true });
  } catch (error) {
    console.log("Error saving API key:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

app.post("/make-server-acb28b15/ai-pricing/process", async (c) => {
  try {
    const { requirements } = await c.req.json();
    const apiKey = await kv.get("config:openai_api_key");

    if (!apiKey) {
      return c.json({ success: false, error: "OpenAI API key not configured" }, 400);
    }

    console.log("Processing requirements with AI...");

    // Call OpenAI API to process requirements
    const openaiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `You are an expert pricing system architect. Your task is to analyze pricing requirements and generate structured configuration for a quote management system.

Your response must be valid JSON with this exact structure:
{
  "headerFields": [
    {
      "id": "unique_field_id",
      "name": "field_name",
      "displayName": "Human Readable Name",
      "type": "string|number|currency|percent|date|select|boolean",
      "required": true|false,
      "editable": true|false,
      "visible": true|false,
      "calculated": true|false,
      "defaultValue": any,
      "options": ["option1", "option2"],
      "description": "Field description"
    }
  ],
  "lineItemFields": [
    {
      "id": "unique_field_id",
      "name": "field_name",
      "displayName": "Human Readable Name",
      "type": "string|number|currency|percent|date|select|boolean",
      "required": true|false,
      "editable": true|false,
      "visible": true|false,
      "calculated": true|false,
      "defaultValue": any,
      "width": number,
      "description": "Field description"
    }
  ],
  "calculationRules": [
    {
      "id": "rule_id",
      "name": "Rule Name",
      "description": "What this rule does",
      "type": "line_item|header|validation",
      "targetField": "field_name",
      "formula": "executable formula or logic",
      "conditions": {},
      "priority": number
    }
  ],
  "explanation": "A clear explanation of the pricing logic you interpreted"
}

Guidelines:
- Extract all header and line item fields from the requirements
- Mark calculated fields appropriately
- Convert pricing logic into executable calculation rules
- Include validation rules
- Ensure formulas are clear and executable
- Provide a helpful explanation of what you understood`
          },
          {
            role: "user",
            content: `Please analyze these pricing requirements and generate the configuration:\n\n${requirements}`
          }
        ],
        temperature: 0.3,
        response_format: { type: "json_object" }
      }),
    });

    if (!openaiResponse.ok) {
      const errorText = await openaiResponse.text();
      console.log("OpenAI API error:", errorText);
      return c.json({ 
        success: false, 
        error: `OpenAI API error: ${openaiResponse.status} - ${errorText}` 
      }, 500);
    }

    const openaiData = await openaiResponse.json();
    console.log("OpenAI response received");

    const aiResponse = JSON.parse(openaiData.choices[0].message.content);

    // Store the processed configuration
    await kv.set("ai_pricing:last_processed", {
      timestamp: new Date().toISOString(),
      requirements,
      result: aiResponse,
    });

    return c.json({
      success: true,
      headerFields: aiResponse.headerFields || [],
      lineItemFields: aiResponse.lineItemFields || [],
      calculationRules: aiResponse.calculationRules || [],
      aiExplanation: aiResponse.explanation || "Configuration processed successfully.",
    });

  } catch (error) {
    console.log("Error processing requirements:", error);
    return c.json({ 
      success: false, 
      error: error instanceof Error ? error.message : String(error) 
    }, 500);
  }
});

app.post("/make-server-acb28b15/ai-pricing/rules", async (c) => {
  try {
    const { rules } = await c.req.json();
    await kv.set("config:calculation_rules", rules);
    return c.json({ success: true });
  } catch (error) {
    console.log("Error saving calculation rules:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

app.get("/make-server-acb28b15/ai-pricing/rules", async (c) => {
  try {
    const rules = await kv.get("config:calculation_rules");
    return c.json({ success: true, data: rules || [] });
  } catch (error) {
    console.log("Error fetching calculation rules:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Endpoint to execute pricing calculations for a quote
app.post("/make-server-acb28b15/ai-pricing/calculate", async (c) => {
  try {
    const { quoteData } = await c.req.json();
    const rules = await kv.get("config:calculation_rules");

    if (!rules || rules.length === 0) {
      return c.json({ 
        success: false, 
        error: "No calculation rules configured. Please process pricing requirements first." 
      }, 400);
    }

    // Execute calculation rules
    // This is a simplified executor - in production, you'd want a more robust calculation engine
    const calculatedData = { ...quoteData };

    // Process line item calculations
    if (calculatedData.lineItems) {
      calculatedData.lineItems = calculatedData.lineItems.map((item: any) => {
        const calculatedItem = { ...item };
        
        // Apply line item calculation rules
        rules
          .filter((rule: any) => rule.type === 'line_item')
          .sort((a: any, b: any) => (a.priority || 0) - (b.priority || 0))
          .forEach((rule: any) => {
            try {
              // Simple formula execution (in production, use a safe expression evaluator)
              if (rule.formula) {
                // This is a placeholder - you'd implement safe formula execution here
                console.log(`Executing rule: ${rule.name} - ${rule.formula}`);
              }
            } catch (error) {
              console.log(`Error executing rule ${rule.name}:`, error);
            }
          });

        return calculatedItem;
      });
    }

    // Process header calculations
    rules
      .filter((rule: any) => rule.type === 'header')
      .sort((a: any, b: any) => (a.priority || 0) - (b.priority || 0))
      .forEach((rule: any) => {
        try {
          if (rule.formula) {
            console.log(`Executing header rule: ${rule.name} - ${rule.formula}`);
          }
        } catch (error) {
          console.log(`Error executing rule ${rule.name}:`, error);
        }
      });

    return c.json({ success: true, data: calculatedData });

  } catch (error) {
    console.log("Error executing calculations:", error);
    return c.json({ 
      success: false, 
      error: error instanceof Error ? error.message : String(error) 
    }, 500);
  }
});

// ============== Field-Level Logic Endpoints ==============
app.post("/make-server-acb28b15/field-logic/validate", async (c) => {
  try {
    const { fieldName, fieldType, plainTextLogic, availableTables } = await c.req.json();
    const apiKey = await kv.get("config:openai_api_key");

    if (!apiKey) {
      return c.json({ 
        valid: false, 
        errors: [{
          type: 'syntax_error',
          message: 'OpenAI API key not configured',
          suggestion: 'Please configure your API key in Settings',
          severity: 'error'
        }]
      }, 400);
    }

    console.log(`Validating field logic for ${fieldType}.${fieldName}...`);

    // Get table schemas for validation
    const tableSchemas = await kv.get("table_schemas");

    // Call OpenAI with function calling for structured validation
    const openaiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `You are an expert pricing logic analyzer and code generator. Your task is to:
1. Parse plain English pricing logic descriptions
2. Identify all table references and validate they exist
3. Identify column references and validate they exist in the tables
4. Generate executable JavaScript/TypeScript code for the logic
5. Detect circular dependencies
6. Provide clear error messages and suggestions

Available tables: ${JSON.stringify(availableTables)}
Table schemas: ${JSON.stringify(tableSchemas || {})}

You must respond with valid JSON containing:
{
  "valid": true/false,
  "errors": [
    {
      "type": "missing_table|missing_column|syntax_error|circular_dependency",
      "message": "Clear error description",
      "suggestion": "How to fix this issue",
      "severity": "error|warning"
    }
  ],
  "tableDependencies": ["table1", "table2"],
  "columnDependencies": {
    "table1": ["col1", "col2"],
    "table2": ["col3"]
  },
  "generatedCode": "// JavaScript/TypeScript code that implements the logic",
  "explanation": "What the logic does in simple terms"
}

Generate production-ready code with:
- Proper error handling
- Type safety
- Table lookups using the provided context
- Clear variable names
- Comments explaining key steps`
          },
          {
            role: "user",
            content: `Field: ${fieldType}.${fieldName}

Pricing Logic:
${plainTextLogic}

Please analyze this logic, validate all table and column references, and generate executable code.`
          }
        ],
        temperature: 0.2,
        response_format: { type: "json_object" }
      }),
    });

    if (!openaiResponse.ok) {
      const errorText = await openaiResponse.text();
      console.log("OpenAI API error:", errorText);
      return c.json({ 
        valid: false,
        errors: [{
          type: 'syntax_error',
          message: `AI validation failed: ${openaiResponse.status}`,
          suggestion: 'Please check your API key and try again',
          severity: 'error'
        }]
      });
    }

    const openaiData = await openaiResponse.json();
    const result = JSON.parse(openaiData.choices[0].message.content);

    // Additional validation: Check if referenced tables actually exist
    if (result.tableDependencies) {
      const missingTables = result.tableDependencies.filter(
        (table: string) => !availableTables.includes(table)
      );

      if (missingTables.length > 0) {
        result.valid = false;
        result.errors = result.errors || [];
        result.errors.push(...missingTables.map((table: string) => ({
          type: 'missing_table',
          message: `Table "${table}" does not exist in the database`,
          suggestion: `Available tables are: ${availableTables.join(', ')}. Please use one of these or create the "${table}" table first.`,
          severity: 'error'
        })));
      }
    }

    // Validate column references against schemas
    if (result.columnDependencies && tableSchemas) {
      for (const [table, columns] of Object.entries(result.columnDependencies)) {
        const schema = tableSchemas[table];
        if (schema && schema.columns) {
          const availableColumns = schema.columns.map((col: any) => col.name);
          const missingColumns = (columns as string[]).filter(
            col => !availableColumns.includes(col)
          );

          if (missingColumns.length > 0) {
            result.valid = false;
            result.errors = result.errors || [];
            result.errors.push(...missingColumns.map(col => ({
              type: 'missing_column',
              message: `Column "${col}" does not exist in table "${table}"`,
              suggestion: `Available columns in "${table}": ${availableColumns.join(', ')}`,
              severity: 'error'
            })));
          }
        }
      }
    }

    return c.json(result);

  } catch (error) {
    console.log("Error validating field logic:", error);
    return c.json({ 
      valid: false,
      errors: [{
        type: 'syntax_error',
        message: error instanceof Error ? error.message : String(error),
        suggestion: 'Please check your logic and try again',
        severity: 'error'
      }]
    });
  }
});

app.post("/make-server-acb28b15/field-logic/save", async (c) => {
  try {
    const { logic } = await c.req.json();
    
    // Get existing logics
    const existingLogics = await kv.get("field_logics") || [];
    
    // Update or add the logic
    const updatedLogics = existingLogics.filter(
      (l: any) => l.id !== logic.id
    );
    updatedLogics.push(logic);
    
    await kv.set("field_logics", updatedLogics);
    
    console.log(`Saved logic for ${logic.fieldType}.${logic.fieldName} (version ${logic.version})`);
    
    return c.json({ success: true, data: logic });
  } catch (error) {
    console.log("Error saving field logic:", error);
    return c.json({ 
      success: false, 
      error: error instanceof Error ? error.message : String(error) 
    }, 500);
  }
});

app.get("/make-server-acb28b15/field-logic/list", async (c) => {
  try {
    const logics = await kv.get("field_logics") || [];
    return c.json({ success: true, data: logics });
  } catch (error) {
    console.log("Error listing field logics:", error);
    return c.json({ 
      success: false, 
      error: error instanceof Error ? error.message : String(error) 
    }, 500);
  }
});

app.delete("/make-server-acb28b15/field-logic/delete", async (c) => {
  try {
    const { logicId } = await c.req.json();
    
    const existingLogics = await kv.get("field_logics") || [];
    const updatedLogics = existingLogics.filter((l: any) => l.id !== logicId);
    
    await kv.set("field_logics", updatedLogics);
    
    console.log(`Deleted logic ${logicId}`);
    
    return c.json({ success: true });
  } catch (error) {
    console.log("Error deleting field logic:", error);
    return c.json({ 
      success: false, 
      error: error instanceof Error ? error.message : String(error) 
    }, 500);
  }
});

app.get("/make-server-acb28b15/field-logic/get/:fieldName/:fieldType", async (c) => {
  try {
    const { fieldName, fieldType } = c.req.param();
    
    const logics = await kv.get("field_logics") || [];
    const logic = logics.find(
      (l: any) => l.fieldName === fieldName && l.fieldType === fieldType
    );
    
    if (logic) {
      return c.json({ success: true, data: logic });
    } else {
      return c.json({ success: false, error: "Logic not found" }, 404);
    }
  } catch (error) {
    console.log("Error getting field logic:", error);
    return c.json({ 
      success: false, 
      error: error instanceof Error ? error.message : String(error) 
    }, 500);
  }
});

// Execute field logic with actual data
app.post("/make-server-acb28b15/field-logic/execute", async (c) => {
  try {
    const { fieldName, fieldType, context } = await c.req.json();
    
    // Get the logic for this field
    const logics = await kv.get("field_logics") || [];
    const logic = logics.find(
      (l: any) => l.fieldName === fieldName && l.fieldType === fieldType
    );
    
    if (!logic || logic.validationStatus !== 'valid') {
      return c.json({ 
        success: false, 
        error: "No valid logic found for this field" 
      }, 404);
    }
    
    // Execute the generated code in a safe context
    // This is a simplified version - in production, use a proper sandbox
    try {
      // Create a function from the generated code
      const executorFunction = new Function('context', 'tableData', logic.generatedCode);
      
      // Get table data for dependencies
      const tableData: any = {};
      for (const tableName of logic.tableDependencies || []) {
        const data = await kv.getByPrefix(`table:${tableName}:`);
        tableData[tableName] = data;
      }
      
      // Execute the logic
      const result = executorFunction(context, tableData);
      
      console.log(`Executed logic for ${fieldType}.${fieldName}: ${result}`);
      
      return c.json({ success: true, data: result });
      
    } catch (execError) {
      console.log("Error executing field logic code:", execError);
      return c.json({ 
        success: false, 
        error: `Execution error: ${execError instanceof Error ? execError.message : String(execError)}`
      }, 500);
    }
    
  } catch (error) {
    console.log("Error in field logic execution:", error);
    return c.json({ 
      success: false, 
      error: error instanceof Error ? error.message : String(error) 
    }, 500);
  }
});

// ============== Table Schemas for Table Manager ==============
app.get("/make-server-acb28b15/table-schemas", async (c) => {
  try {
    // Return the schema definitions for all available tables
    const schemas = [
      {
        name: 'product_hierarchies',
        displayName: 'Product Hierarchies',
        primaryKey: 'id',
        fields: [
          { name: 'id', type: 'string', label: 'ID', required: true },
          { name: 'name', type: 'string', label: 'Name', required: true },
          { name: 'description', type: 'string', label: 'Description', required: false }
        ]
      },
      {
        name: 'customers',
        displayName: 'Customers',
        primaryKey: 'id',
        fields: [
          { name: 'id', type: 'string', label: 'ID', required: true },
          { name: 'name', type: 'string', label: 'Name', required: true },
          { name: 'type', type: 'string', label: 'Type', required: false },
          { name: 'region', type: 'string', label: 'Region', required: false },
          { name: 'country', type: 'string', label: 'Country', required: false }
        ]
      },
      {
        name: 'sales_orgs',
        displayName: 'Sales Organizations',
        primaryKey: 'id',
        fields: [
          { name: 'id', type: 'string', label: 'ID', required: true },
          { name: 'name', type: 'string', label: 'Name', required: true },
          { name: 'region', type: 'string', label: 'Region', required: false }
        ]
      },
      {
        name: 'regions',
        displayName: 'Regions',
        primaryKey: 'id',
        fields: [
          { name: 'id', type: 'string', label: 'ID', required: true },
          { name: 'name', type: 'string', label: 'Name', required: true }
        ]
      },
      {
        name: 'countries',
        displayName: 'Countries',
        primaryKey: 'id',
        fields: [
          { name: 'id', type: 'string', label: 'ID', required: true },
          { name: 'name', type: 'string', label: 'Name', required: true },
          { name: 'code', type: 'string', label: 'Code', required: false },
          { name: 'region', type: 'string', label: 'Region', required: false }
        ]
      },
      {
        name: 'currencies',
        displayName: 'Currencies',
        primaryKey: 'id',
        fields: [
          { name: 'id', type: 'string', label: 'ID', required: true },
          { name: 'code', type: 'string', label: 'Code', required: true },
          { name: 'name', type: 'string', label: 'Name', required: true },
          { name: 'symbol', type: 'string', label: 'Symbol', required: false }
        ]
      },
      {
        name: 'price_lists',
        displayName: 'Price Lists',
        primaryKey: 'id',
        fields: [
          { name: 'id', type: 'string', label: 'ID', required: true },
          { name: 'name', type: 'string', label: 'Name', required: true },
          { name: 'type', type: 'string', label: 'Type', required: false },
          { name: 'validFrom', type: 'string', label: 'Valid From', required: false },
          { name: 'validTo', type: 'string', label: 'Valid To', required: false }
        ]
      },
      {
        name: 'payment_terms',
        displayName: 'Payment Terms',
        primaryKey: 'id',
        fields: [
          { name: 'id', type: 'string', label: 'ID', required: true },
          { name: 'name', type: 'string', label: 'Name', required: true },
          { name: 'days', type: 'number', label: 'Days', required: false },
          { name: 'description', type: 'string', label: 'Description', required: false }
        ]
      },
      {
        name: 'products',
        displayName: 'Products',
        primaryKey: 'id',
        fields: [
          { name: 'id', type: 'string', label: 'ID', required: true },
          { name: 'sku', type: 'string', label: 'SKU', required: true },
          { name: 'productName', type: 'string', label: 'Product Name', required: true },
          { name: 'listPrice', type: 'number', label: 'List Price', required: false },
          { name: 'cost', type: 'number', label: 'Cost', required: false },
          { name: 'category', type: 'string', label: 'Category', required: false },
          { name: 'description', type: 'string', label: 'Description', required: false }
        ]
      }
    ];
    
    return c.json({ success: true, data: schemas });
  } catch (error) {
    console.log("Error fetching table schemas:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// ============== Generic Table Data Endpoints ==============
app.get("/make-server-acb28b15/tables/:tableName/data", async (c) => {
  try {
    const tableName = c.req.param("tableName");
    const prefix = tableName.replace(/_/g, '_').replace(/s$/, '') + ':';
    const items = await kv.getByPrefix(prefix);
    return c.json({ success: true, data: items });
  } catch (error) {
    console.log("Error fetching table data:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

app.post("/make-server-acb28b15/tables/:tableName/data", async (c) => {
  try {
    const tableName = c.req.param("tableName");
    const record = await c.req.json();
    const recordId = record.id || `${tableName}_${Date.now()}`;
    const prefix = tableName.replace(/_/g, '_').replace(/s$/, '') + ':';
    await kv.set(`${prefix}${recordId}`, { ...record, id: recordId });
    return c.json({ success: true, data: { ...record, id: recordId } });
  } catch (error) {
    console.log("Error adding table record:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

app.put("/make-server-acb28b15/tables/:tableName/data/:id", async (c) => {
  try {
    const tableName = c.req.param("tableName");
    const id = c.req.param("id");
    const record = await c.req.json();
    const prefix = tableName.replace(/_/g, '_').replace(/s$/, '') + ':';
    await kv.set(`${prefix}${id}`, { ...record, id });
    return c.json({ success: true, data: { ...record, id } });
  } catch (error) {
    console.log("Error updating table record:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

app.delete("/make-server-acb28b15/tables/:tableName/data/:id", async (c) => {
  try {
    const tableName = c.req.param("tableName");
    const id = c.req.param("id");
    const prefix = tableName.replace(/_/g, '_').replace(/s$/, '') + ':';
    await kv.del(`${prefix}${id}`);
    return c.json({ success: true });
  } catch (error) {
    console.log("Error deleting table record:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

Deno.serve(app.fetch);