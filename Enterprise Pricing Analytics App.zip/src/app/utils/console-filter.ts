// Suppress browser extension interference errors
(() => {
  // Store original console methods
  const originalError = console.error;
  const originalWarn = console.warn;

  // List of patterns to suppress
  const suppressPatterns = [
    /MetaMask/i,
    /chrome-extension/i,
    /extensions\//i,
    /Failed to connect to MetaMask/i,
  ];

  // Override console.error
  console.error = (...args: any[]) => {
    const message = args.join(' ');
    
    // Check if message matches any suppress pattern
    const shouldSuppress = suppressPatterns.some(pattern => 
      pattern.test(message)
    );

    if (!shouldSuppress) {
      originalError.apply(console, args);
    }
  };

  // Override console.warn
  console.warn = (...args: any[]) => {
    const message = args.join(' ');
    
    // Check if message matches any suppress pattern
    const shouldSuppress = suppressPatterns.some(pattern => 
      pattern.test(message)
    );

    if (!shouldSuppress) {
      originalWarn.apply(console, args);
    }
  };

  // Log that filtering is active (only in development)
  if (import.meta.env.DEV) {
    console.info('✓ Console filtering active - browser extension errors suppressed');
  }
})();
