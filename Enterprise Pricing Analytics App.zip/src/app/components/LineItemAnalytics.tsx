import React from 'react';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, DollarSign, Percent, Package } from 'lucide-react';
import { LineItem } from './PricingTable';

interface LineItemAnalyticsProps {
  item: LineItem;
}

export function LineItemAnalytics({ item }: LineItemAnalyticsProps) {
  // Prepare data for price breakdown
  const priceBreakdown = [
    {
      name: 'List Price',
      value: item.listPrice,
      color: '#3b82f6',
    },
    {
      name: 'After Discount',
      value: item.listPrice * (1 - item.volumeDiscount / 100),
      color: '#8b5cf6',
    },
    {
      name: 'Net Price',
      value: item.netPrice,
      color: '#10b981',
    },
    {
      name: 'Cost',
      value: item.cost,
      color: '#ef4444',
    },
  ];

  // Margin analysis data
  const marginData = [
    { name: 'Revenue', value: item.totalValue },
    { name: 'Cost', value: item.cost * item.quantity },
    { name: 'Profit', value: item.totalValue - (item.cost * item.quantity) },
  ];

  // Volume sensitivity analysis
  const volumeSensitivity = [10, 25, 50, 75, 100, 150, 200].map((qty) => {
    const discountedPrice = item.listPrice * (1 - item.volumeDiscount / 100);
    const totalBeforeRebate = discountedPrice * qty;
    const totalAfterRebate = totalBeforeRebate - item.rebate;
    const totalCost = item.cost * qty;
    const margin = totalAfterRebate > 0 ? ((totalAfterRebate - totalCost) / totalAfterRebate) * 100 : 0;
    
    return {
      quantity: qty,
      revenue: totalAfterRebate,
      cost: totalCost,
      margin: margin,
    };
  });

  // Discount impact analysis
  const discountImpact = [0, 5, 10, 15, 20, 25, 30].map((discount) => {
    const discountedPrice = item.listPrice * (1 - discount / 100);
    const totalBeforeRebate = discountedPrice * item.quantity;
    const totalAfterRebate = totalBeforeRebate - item.rebate;
    const totalCost = item.cost * item.quantity;
    const margin = totalAfterRebate > 0 ? ((totalAfterRebate - totalCost) / totalAfterRebate) * 100 : 0;
    
    return {
      discount: `${discount}%`,
      margin: margin,
      revenue: totalAfterRebate,
    };
  });

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const COLORS = ['#3b82f6', '#ef4444', '#10b981'];

  return (
    <div className="p-6 space-y-6">
      {/* Key Metrics Row */}
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center gap-2 text-gray-600 mb-2">
            <DollarSign className="w-4 h-4" />
            <span className="text-sm">Revenue</span>
          </div>
          <div className="text-2xl font-semibold text-gray-900">
            {formatCurrency(item.totalValue)}
          </div>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center gap-2 text-gray-600 mb-2">
            <TrendingUp className="w-4 h-4" />
            <span className="text-sm">Profit</span>
          </div>
          <div className="text-2xl font-semibold text-green-600">
            {formatCurrency(item.totalValue - (item.cost * item.quantity))}
          </div>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center gap-2 text-gray-600 mb-2">
            <Percent className="w-4 h-4" />
            <span className="text-sm">Margin</span>
          </div>
          <div className="text-2xl font-semibold text-purple-600">
            {item.margin.toFixed(2)}%
          </div>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center gap-2 text-gray-600 mb-2">
            <Package className="w-4 h-4" />
            <span className="text-sm">Units</span>
          </div>
          <div className="text-2xl font-semibold text-gray-900">
            {item.quantity}
          </div>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-2 gap-6">
        {/* Price Breakdown */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-sm font-medium text-gray-900 mb-4">Price Breakdown</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={priceBreakdown}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} tickFormatter={(value) => `$${value}`} />
              <Tooltip
                formatter={(value: number) => formatCurrency(value)}
                contentStyle={{ backgroundColor: 'white', border: '1px solid #e5e7eb' }}
              />
              <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                {priceBreakdown.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Revenue vs Cost */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-sm font-medium text-gray-900 mb-4">Revenue vs Cost vs Profit</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={marginData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {marginData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value: number) => formatCurrency(value)} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Volume Sensitivity */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-sm font-medium text-gray-900 mb-4">Volume Sensitivity Analysis</h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={volumeSensitivity}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="quantity" tick={{ fontSize: 12 }} label={{ value: 'Quantity', position: 'insideBottom', offset: -5, fontSize: 12 }} />
              <YAxis 
                yAxisId="left" 
                tick={{ fontSize: 12 }} 
                tickFormatter={(value) => formatCurrency(value)}
              />
              <YAxis 
                yAxisId="right" 
                orientation="right" 
                tick={{ fontSize: 12 }}
                tickFormatter={(value) => `${value.toFixed(0)}%`}
              />
              <Tooltip
                formatter={(value: number, name: string) => {
                  if (name === 'margin') return `${value.toFixed(2)}%`;
                  return formatCurrency(value);
                }}
                contentStyle={{ backgroundColor: 'white', border: '1px solid #e5e7eb' }}
              />
              <Legend />
              <Line yAxisId="left" type="monotone" dataKey="revenue" stroke="#3b82f6" strokeWidth={2} name="Revenue" />
              <Line yAxisId="left" type="monotone" dataKey="cost" stroke="#ef4444" strokeWidth={2} name="Cost" />
              <Line yAxisId="right" type="monotone" dataKey="margin" stroke="#10b981" strokeWidth={2} name="Margin %" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Discount Impact */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-sm font-medium text-gray-900 mb-4">Discount Impact on Margin</h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={discountImpact}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="discount" tick={{ fontSize: 12 }} label={{ value: 'Volume Discount', position: 'insideBottom', offset: -5, fontSize: 12 }} />
              <YAxis 
                yAxisId="left"
                tick={{ fontSize: 12 }}
                tickFormatter={(value) => `${value.toFixed(0)}%`}
              />
              <YAxis 
                yAxisId="right" 
                orientation="right" 
                tick={{ fontSize: 12 }}
                tickFormatter={(value) => formatCurrency(value)}
              />
              <Tooltip
                formatter={(value: number, name: string) => {
                  if (name === 'margin') return `${value.toFixed(2)}%`;
                  return formatCurrency(value);
                }}
                contentStyle={{ backgroundColor: 'white', border: '1px solid #e5e7eb' }}
              />
              <Legend />
              <Line yAxisId="left" type="monotone" dataKey="margin" stroke="#8b5cf6" strokeWidth={2} name="Margin %" />
              <Line yAxisId="right" type="monotone" dataKey="revenue" stroke="#3b82f6" strokeWidth={2} name="Revenue" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Additional Insights */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-blue-50 rounded-lg border border-blue-200 p-4">
          <div className="text-sm text-blue-700 mb-1">Effective Discount</div>
          <div className="text-xl font-semibold text-blue-900">
            {(((item.listPrice - item.netPrice) / item.listPrice) * 100).toFixed(2)}%
          </div>
          <div className="text-xs text-blue-600 mt-1">
            Includes volume discount + rebate impact
          </div>
        </div>
        <div className="bg-green-50 rounded-lg border border-green-200 p-4">
          <div className="text-sm text-green-700 mb-1">Profit per Unit</div>
          <div className="text-xl font-semibold text-green-900">
            {formatCurrency(item.netPrice - item.cost)}
          </div>
          <div className="text-xs text-green-600 mt-1">
            Net price minus cost
          </div>
        </div>
        <div className="bg-purple-50 rounded-lg border border-purple-200 p-4">
          <div className="text-sm text-purple-700 mb-1">Break-even Quantity</div>
          <div className="text-xl font-semibold text-purple-900">
            {item.rebate > 0 && item.listPrice > item.cost
              ? Math.ceil(item.rebate / ((item.listPrice * (1 - item.volumeDiscount / 100)) - item.cost))
              : 'N/A'}
          </div>
          <div className="text-xs text-purple-600 mt-1">
            Units needed to cover rebate
          </div>
        </div>
      </div>
    </div>
  );
}
