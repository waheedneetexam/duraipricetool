import React, { useState, useEffect } from 'react';
import { 
  Settings, Plus, Trash2, GripVertical, Save, RefreshCw, 
  AlertCircle, Check, ArrowLeft, Eye, EyeOff
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';
import { projectId, publicAnonKey } from '/utils/supabase/info';

interface LineItemField {
  id: string;
  name: string;
  displayName: string;
  type: 'string' | 'number' | 'boolean' | 'date' | 'select' | 'percent' | 'currency';
  editable: boolean;
  visible: boolean;
  required: boolean;
  defaultValue?: any;
  options?: string[];
  width?: number;
  locked?: boolean; // System fields that can't be deleted
}

const DEFAULT_FIELDS: LineItemField[] = [
  { id: 'id', name: 'id', displayName: 'ID', type: 'string', editable: false, visible: false, required: true, locked: true },
  { id: 'productName', name: 'productName', displayName: 'Product Name', type: 'string', editable: true, visible: true, required: true, width: 200, locked: true },
  { id: 'quantity', name: 'quantity', displayName: 'Quantity', type: 'number', editable: true, visible: true, required: true, defaultValue: 1, width: 100, locked: true },
  { id: 'listPrice', name: 'listPrice', displayName: 'List Price', type: 'currency', editable: true, visible: true, required: true, defaultValue: 0, width: 120, locked: true },
  { id: 'discount', name: 'discount', displayName: 'Discount %', type: 'percent', editable: true, visible: true, required: false, defaultValue: 0, width: 120, locked: true },
  { id: 'netPrice', name: 'netPrice', displayName: 'Net Price', type: 'currency', editable: false, visible: true, required: false, width: 120, locked: true },
  { id: 'extendedPrice', name: 'extendedPrice', displayName: 'Extended Price', type: 'currency', editable: false, visible: true, required: false, width: 140, locked: true },
];

const FIELD_TYPES = [
  { value: 'string', label: 'Text', icon: 'Aa' },
  { value: 'number', label: 'Number', icon: '#' },
  { value: 'currency', label: 'Currency', icon: '$' },
  { value: 'percent', label: 'Percent', icon: '%' },
  { value: 'boolean', label: 'Yes/No', icon: '✓' },
  { value: 'date', label: 'Date', icon: '📅' },
  { value: 'select', label: 'Dropdown', icon: '▼' },
];

interface LineItemConfiguratorProps {
  onBack: () => void;
}

export function LineItemConfigurator({ onBack }: LineItemConfiguratorProps) {
  const [fields, setFields] = useState<LineItemField[]>(DEFAULT_FIELDS);
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [editingField, setEditingField] = useState<LineItemField | null>(null);
  const [showAddField, setShowAddField] = useState(false);

  useEffect(() => {
    loadConfiguration();
  }, []);

  const loadConfiguration = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/config/line-item-fields`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
          },
        }
      );

      const result = await response.json();
      if (result.success && result.data) {
        setFields(result.data);
      }
    } catch (err) {
      console.error('Error loading configuration:', err);
      setError('Failed to load configuration');
    } finally {
      setIsLoading(false);
    }
  };

  const saveConfiguration = async () => {
    setIsSaving(true);
    setError(null);
    setSuccess(null);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/config/line-item-fields`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({ fields }),
        }
      );

      const result = await response.json();
      if (result.success) {
        setSuccess('Configuration saved successfully! Changes will appear in the Quote screen.');
        setTimeout(() => setSuccess(null), 3000);
      } else {
        setError('Failed to save configuration');
      }
    } catch (err) {
      console.error('Error saving configuration:', err);
      setError('Failed to save configuration: ' + String(err));
    } finally {
      setIsSaving(false);
    }
  };

  const addNewField = () => {
    const newField: LineItemField = {
      id: `custom_${Date.now()}`,
      name: '',
      displayName: '',
      type: 'string',
      editable: true,
      visible: true,
      required: false,
      width: 150,
      locked: false,
    };
    setEditingField(newField);
    setShowAddField(true);
  };

  const saveNewField = () => {
    if (!editingField?.name || !editingField?.displayName) {
      setError('Please provide field name and display name');
      return;
    }

    const nameExists = fields.some(f => f.name === editingField.name && f.id !== editingField.id);
    if (nameExists) {
      setError('A field with this name already exists');
      return;
    }

    if (editingField.id.startsWith('custom_') && !fields.find(f => f.id === editingField.id)) {
      setFields([...fields, editingField]);
    } else {
      setFields(fields.map(f => f.id === editingField.id ? editingField : f));
    }
    
    setShowAddField(false);
    setEditingField(null);
    setError(null);
  };

  const deleteField = (fieldId: string) => {
    const field = fields.find(f => f.id === fieldId);
    if (field?.locked) {
      setError('Cannot delete system fields');
      return;
    }

    if (confirm(`Are you sure you want to delete the field "${field?.displayName}"?`)) {
      setFields(fields.filter(f => f.id !== fieldId));
    }
  };

  const toggleFieldVisibility = (fieldId: string) => {
    setFields(fields.map(f => 
      f.id === fieldId ? { ...f, visible: !f.visible } : f
    ));
  };

  const moveField = (index: number, direction: 'up' | 'down') => {
    const newFields = [...fields];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    
    if (targetIndex < 0 || targetIndex >= newFields.length) return;
    
    [newFields[index], newFields[targetIndex]] = [newFields[targetIndex], newFields[index]];
    setFields(newFields);
  };

  const resetToDefault = () => {
    if (confirm('Are you sure you want to reset to default configuration? This will delete all custom fields.')) {
      setFields(DEFAULT_FIELDS);
      setSuccess('Reset to default configuration');
      setTimeout(() => setSuccess(null), 3000);
    }
  };

  return (
    <div className="w-full h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-3">
              <Settings className="w-8 h-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-semibold text-gray-900">Line Item Configurator</h1>
                <p className="text-sm text-gray-500 mt-1">Customize fields for quote line items</p>
              </div>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={resetToDefault} className="gap-2">
              <RefreshCw className="w-4 h-4" />
              Reset to Default
            </Button>
            <Button variant="outline" onClick={loadConfiguration} className="gap-2" disabled={isLoading}>
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
              Reload
            </Button>
            <Button onClick={saveConfiguration} className="gap-2" disabled={isSaving}>
              <Save className="w-4 h-4" />
              {isSaving ? 'Saving...' : 'Save Configuration'}
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto p-6">
        <div className="max-w-6xl mx-auto">
          {error && (
            <Alert className="mb-4 border-red-200 bg-red-50">
              <AlertCircle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800">{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="mb-4 border-green-200 bg-green-50">
              <Check className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-800">{success}</AlertDescription>
            </Alert>
          )}

          {/* Add New Field Form */}
          {showAddField && editingField && (
            <Card className="p-6 mb-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">
                  {editingField.id.startsWith('custom_') && !fields.find(f => f.id === editingField.id) 
                    ? 'Add New Field' 
                    : 'Edit Field'}
                </h3>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => {
                    setShowAddField(false);
                    setEditingField(null);
                    setError(null);
                  }}>
                    Cancel
                  </Button>
                  <Button size="sm" onClick={saveNewField}>
                    Save Field
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium mb-2 block">Field Name (Internal)</Label>
                  <Input
                    value={editingField.name}
                    onChange={(e) => setEditingField({ ...editingField, name: e.target.value })}
                    placeholder="e.g., delivery_date"
                  />
                  <p className="text-xs text-gray-500 mt-1">Lowercase, no spaces (use underscores)</p>
                </div>

                <div>
                  <Label className="text-sm font-medium mb-2 block">Display Name</Label>
                  <Input
                    value={editingField.displayName}
                    onChange={(e) => setEditingField({ ...editingField, displayName: e.target.value })}
                    placeholder="e.g., Delivery Date"
                  />
                  <p className="text-xs text-gray-500 mt-1">Shown in the table header</p>
                </div>

                <div>
                  <Label className="text-sm font-medium mb-2 block">Field Type</Label>
                  <Select
                    value={editingField.type}
                    onValueChange={(v: any) => setEditingField({ ...editingField, type: v })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {FIELD_TYPES.map((ft) => (
                        <SelectItem key={ft.value} value={ft.value}>
                          {ft.icon} {ft.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-sm font-medium mb-2 block">Column Width (px)</Label>
                  <Input
                    type="number"
                    value={editingField.width || 150}
                    onChange={(e) => setEditingField({ ...editingField, width: parseInt(e.target.value) })}
                    placeholder="150"
                  />
                </div>

                <div>
                  <Label className="text-sm font-medium mb-2 block">Default Value</Label>
                  <Input
                    value={editingField.defaultValue || ''}
                    onChange={(e) => setEditingField({ ...editingField, defaultValue: e.target.value })}
                    placeholder="Optional default value"
                  />
                </div>

                {editingField.type === 'select' && (
                  <div>
                    <Label className="text-sm font-medium mb-2 block">Options (comma-separated)</Label>
                    <Input
                      value={editingField.options?.join(', ') || ''}
                      onChange={(e) => setEditingField({ 
                        ...editingField, 
                        options: e.target.value.split(',').map(o => o.trim()) 
                      })}
                      placeholder="Option 1, Option 2, Option 3"
                    />
                  </div>
                )}

                <div className="col-span-2 flex gap-6">
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={editingField.editable}
                      onChange={(e) => setEditingField({ ...editingField, editable: e.target.checked })}
                      className="rounded"
                    />
                    <span className="text-sm text-gray-700">Editable by users</span>
                  </label>

                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={editingField.required}
                      onChange={(e) => setEditingField({ ...editingField, required: e.target.checked })}
                      className="rounded"
                    />
                    <span className="text-sm text-gray-700">Required field</span>
                  </label>

                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={editingField.visible}
                      onChange={(e) => setEditingField({ ...editingField, visible: e.target.checked })}
                      className="rounded"
                    />
                    <span className="text-sm text-gray-700">Visible in table</span>
                  </label>
                </div>
              </div>
            </Card>
          )}

          {/* Fields List */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Line Item Fields</h3>
                <p className="text-sm text-gray-500 mt-1">
                  {fields.filter(f => f.visible).length} visible fields • {fields.length} total fields
                </p>
              </div>
              <Button onClick={addNewField} className="gap-2">
                <Plus className="w-4 h-4" />
                Add Custom Field
              </Button>
            </div>

            <div className="space-y-2">
              {fields.map((field, index) => (
                <div 
                  key={field.id} 
                  className={`flex items-center gap-3 p-4 rounded-lg border ${
                    field.visible ? 'bg-white border-gray-200' : 'bg-gray-50 border-gray-200 opacity-60'
                  }`}
                >
                  {/* Drag Handle */}
                  <div className="flex flex-col gap-1">
                    <button
                      onClick={() => moveField(index, 'up')}
                      disabled={index === 0}
                      className="p-1 hover:bg-gray-100 rounded disabled:opacity-30 disabled:cursor-not-allowed"
                    >
                      <GripVertical className="w-4 h-4 text-gray-400" />
                    </button>
                  </div>

                  {/* Field Info */}
                  <div className="flex-1">
                    <div className="flex items-center gap-3">
                      <h4 className="font-medium text-gray-900">{field.displayName}</h4>
                      {field.locked && (
                        <span className="px-2 py-0.5 bg-blue-100 text-blue-700 text-xs rounded font-medium">
                          System
                        </span>
                      )}
                      {field.required && (
                        <span className="px-2 py-0.5 bg-red-100 text-red-700 text-xs rounded font-medium">
                          Required
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-4 mt-1 text-xs text-gray-500">
                      <code className="bg-gray-100 px-2 py-0.5 rounded">{field.name}</code>
                      <span>Type: {FIELD_TYPES.find(t => t.value === field.type)?.label}</span>
                      <span>Width: {field.width}px</span>
                      {field.editable && <span className="text-green-600">✓ Editable</span>}
                      {!field.editable && <span className="text-gray-400">Read-only</span>}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => toggleFieldVisibility(field.id)}
                      className="gap-2"
                    >
                      {field.visible ? (
                        <>
                          <Eye className="w-4 h-4" />
                          Visible
                        </>
                      ) : (
                        <>
                          <EyeOff className="w-4 h-4" />
                          Hidden
                        </>
                      )}
                    </Button>

                    {!field.locked && (
                      <>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setEditingField(field);
                            setShowAddField(true);
                          }}
                        >
                          Edit
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteField(field.id)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Info Card */}
          <Card className="p-6 mt-6 bg-blue-50 border-blue-200">
            <h3 className="font-semibold text-blue-900 mb-2">How It Works</h3>
            <ul className="text-sm text-blue-800 space-y-1 list-disc list-inside">
              <li>Add custom fields to capture additional data in your quote line items</li>
              <li>System fields (Product Name, Quantity, Price, etc.) cannot be deleted but can be hidden</li>
              <li>Drag fields to reorder them in the table</li>
              <li>Click "Save Configuration" to apply changes to the Quote screen</li>
              <li>Custom fields will appear in all new and existing quotes</li>
            </ul>
          </Card>
        </div>
      </div>
    </div>
  );
}