import React, { useState } from 'react';
import { Upload, FileUp, Check, X, AlertCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';

interface ColumnDefinition {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'date' | 'json' | 'text';
  required: boolean;
}

const DATA_TYPES = [
  { value: 'string', label: 'String', icon: 'Aa' },
  { value: 'number', label: 'Number', icon: '#' },
  { value: 'boolean', label: 'Boolean', icon: '✓' },
  { value: 'date', label: 'Date', icon: '📅' },
  { value: 'text', label: 'Text (Long)', icon: '📝' },
  { value: 'json', label: 'JSON', icon: '{}' },
];

interface CsvTableImporterProps {
  onCancel: () => void;
  onCreate: (tableName: string, displayName: string, columns: ColumnDefinition[], data: any[]) => Promise<void>;
}

export function CsvTableImporter({ onCancel, onCreate }: CsvTableImporterProps) {
  const [tableName, setTableName] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [csvHeaders, setCsvHeaders] = useState<string[]>([]);
  const [csvData, setCsvData] = useState<any[]>([]);
  const [columns, setColumns] = useState<ColumnDefinition[]>([]);
  const [primaryKeyColumn, setPrimaryKeyColumn] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [step, setStep] = useState<1 | 2>(1);

  const parseCsv = (csvText: string): { headers: string[]; data: any[] } => {
    const lines = csvText.trim().split('\n');
    if (lines.length < 2) {
      throw new Error('CSV must have at least a header row and one data row');
    }

    const headers = lines[0].split(',').map(h => h.trim());
    const data: any[] = [];

    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(',').map(v => v.trim());
      const row: any = {};
      headers.forEach((header, index) => {
        row[header] = values[index] || '';
      });
      data.push(row);
    }

    return { headers, data };
  };

  const inferDataType = (value: string): 'string' | 'number' | 'boolean' | 'date' => {
    if (value.toLowerCase() === 'true' || value.toLowerCase() === 'false') {
      return 'boolean';
    }
    
    if (!isNaN(Number(value)) && value !== '') {
      return 'number';
    }
    
    const datePattern = /^\d{4}-\d{2}-\d{2}|^\d{1,2}\/\d{1,2}\/\d{4}/;
    if (datePattern.test(value)) {
      return 'date';
    }
    
    return 'string';
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const csvText = event.target?.result as string;
        const { headers, data } = parseCsv(csvText);
        
        setCsvHeaders(headers);
        setCsvData(data);
        
        const inferredColumns: ColumnDefinition[] = headers.map((header, idx) => {
          const firstValue = data[0]?.[header] || '';
          const inferredType = inferDataType(firstValue);
          
          return {
            name: header,
            type: inferredType,
            required: idx === 0,
          };
        });
        
        setColumns(inferredColumns);
        setPrimaryKeyColumn(headers[0]);
        
        const fileName = file.name.replace('.csv', '');
        setTableName(fileName.toLowerCase().replace(/\s+/g, '_'));
        setDisplayName(fileName.split(/[-_]/).map(word => 
          word.charAt(0).toUpperCase() + word.slice(1)
        ).join(' '));
        
        setStep(2);
        setError(null);
      } catch (err) {
        setError('Failed to parse CSV: ' + String(err));
      }
    };
    reader.readAsText(file);
  };

  const handleCreate = async () => {
    if (!tableName || !displayName) {
      setError('Please provide table name and display name');
      return;
    }

    if (!primaryKeyColumn) {
      setError('Please select a primary key column');
      return;
    }

    const pkIndex = columns.findIndex(col => col.name === primaryKeyColumn);
    const reorderedColumns = [
      columns[pkIndex],
      ...columns.filter((_, idx) => idx !== pkIndex),
    ];

    try {
      await onCreate(tableName, displayName, reorderedColumns, csvData);
    } catch (err) {
      setError('Failed to create table: ' + String(err));
    }
  };

  const updateColumnType = (index: number, type: string) => {
    const updated = [...columns];
    updated[index].type = type as any;
    setColumns(updated);
  };

  const updateColumnRequired = (index: number, required: boolean) => {
    const updated = [...columns];
    updated[index].required = required;
    setColumns(updated);
  };

  if (step === 1) {
    return (
      <div className="w-full h-full bg-gray-50 p-6 overflow-y-auto">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-semibold text-gray-900">Import Table from CSV</h2>
              <p className="text-sm text-gray-500 mt-1">Upload a CSV file to automatically create a table</p>
            </div>
            <Button variant="outline" onClick={onCancel}>
              Cancel
            </Button>
          </div>

          {error && (
            <Alert className="mb-4 border-red-200 bg-red-50">
              <AlertCircle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800">{error}</AlertDescription>
            </Alert>
          )}

          <Card className="p-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <FileUp className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Upload CSV File</h3>
              <p className="text-sm text-gray-500 mb-6">
                The first row should contain column headers. We'll automatically infer data types.
              </p>
              
              <label className="inline-block">
                <Button className="gap-2" onClick={() => document.getElementById('csv-file-input')?.click()}>
                  <Upload className="w-4 h-4" />
                  Choose CSV File
                </Button>
                <input
                  id="csv-file-input"
                  type="file"
                  accept=".csv"
                  className="hidden"
                  onChange={handleFileUpload}
                />
              </label>

              <div className="mt-8 text-left">
                <p className="text-sm font-medium text-gray-700 mb-2">Example CSV Format:</p>
                <div className="bg-gray-50 rounded p-4 font-mono text-xs text-gray-600">
                  id,name,price,active,created_date<br />
                  1,Product A,99.99,true,2024-01-01<br />
                  2,Product B,149.99,false,2024-01-02
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full h-full bg-gray-50 p-6 overflow-y-auto">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-semibold text-gray-900">Configure Table Schema</h2>
            <p className="text-sm text-gray-500 mt-1">
              Review and adjust the column types and settings
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onCancel}>
              Cancel
            </Button>
            <Button onClick={handleCreate}>
              Create Table & Import Data
            </Button>
          </div>
        </div>

        {error && (
          <Alert className="mb-4 border-red-200 bg-red-50">
            <AlertCircle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-800">{error}</AlertDescription>
          </Alert>
        )}

        <Card className="p-6 mb-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-sm font-medium mb-2 block">Table Name (Internal)</Label>
              <Input
                value={tableName}
                onChange={(e) => setTableName(e.target.value)}
                placeholder="e.g., custom_pricing_rules"
              />
              <p className="text-xs text-gray-500 mt-1">Used in API calls (lowercase, underscores)</p>
            </div>
            <div>
              <Label className="text-sm font-medium mb-2 block">Display Name</Label>
              <Input
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="e.g., Custom Pricing Rules"
              />
              <p className="text-xs text-gray-500 mt-1">Shown in the UI</p>
            </div>
          </div>
        </Card>

        <Card className="p-6 mb-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-900">Detected Columns ({columns.length})</h3>
            <div className="text-sm text-gray-500">
              {csvData.length} rows will be imported
            </div>
          </div>

          <div className="space-y-3">
            {columns.map((column, index) => (
              <div key={index} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <div className="flex-1">
                  <p className="font-medium text-sm text-gray-900">{column.name}</p>
                  <p className="text-xs text-gray-500 mt-1">
                    Sample: {csvData[0]?.[column.name]?.toString().substring(0, 50) || 'N/A'}
                  </p>
                </div>
                <div className="w-48">
                  <Select
                    value={column.type}
                    onValueChange={(v) => updateColumnType(index, v)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {DATA_TYPES.map((dt) => (
                        <SelectItem key={dt.value} value={dt.value}>
                          {dt.icon} {dt.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <label className="flex items-center gap-2 w-32">
                  <input
                    type="checkbox"
                    checked={column.required}
                    onChange={(e) => updateColumnRequired(index, e.target.checked)}
                    className="rounded"
                  />
                  <span className="text-sm text-gray-600">Required</span>
                </label>
                <div className="w-24 flex items-center justify-center">
                  <label className="flex items-center gap-2">
                    <input
                      type="radio"
                      name="primaryKey"
                      checked={primaryKeyColumn === column.name}
                      onChange={() => setPrimaryKeyColumn(column.name)}
                      className="rounded-full"
                    />
                    <span className="text-xs text-gray-500">Primary Key</span>
                  </label>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-4">
          <h3 className="font-semibold text-sm text-gray-900 mb-3">Data Preview (First 5 rows)</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-gray-100">
                <tr>
                  {csvHeaders.map((header) => (
                    <th key={header} className="px-3 py-2 text-left font-semibold text-gray-700">
                      {header}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {csvData.slice(0, 5).map((row, idx) => (
                  <tr key={idx} className="hover:bg-gray-50">
                    {csvHeaders.map((header) => (
                      <td key={header} className="px-3 py-2 text-gray-900">
                        {row[header]}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
}
