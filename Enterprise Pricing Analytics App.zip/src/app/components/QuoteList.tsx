import React, { useState, useEffect } from 'react';
import { FileText, Plus, Pencil, Trash2, Search, Calendar } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { projectId, publicAnonKey } from '/utils/supabase/info';

interface Quote {
  id: string;
  description: string;
  customerName: string;
  dateCreated: string;
  dateModified: string;
  totalValue: number;
  lineItemCount: number;
}

interface QuoteListProps {
  onCreateNew: () => void;
  onEditQuote: (quoteId: string) => void;
}

export function QuoteList({ onCreateNew, onEditQuote }: QuoteListProps) {
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [serverError, setServerError] = useState<string | null>(null);

  useEffect(() => {
    checkServerHealth();
  }, []);

  const checkServerHealth = async () => {
    try {
      console.log('Checking server health...');
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/health`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
          },
        }
      );

      console.log('Health check response:', response.status);
      
      if (response.ok) {
        console.log('Server is healthy, fetching quotes...');
        fetchQuotes();
      } else {
        setServerError('Server is not responding. Please try again later.');
        setIsLoading(false);
      }
    } catch (error) {
      console.error('Server health check failed:', error);
      setServerError('Unable to connect to server. The backend may not be deployed yet.');
      setIsLoading(false);
    }
  };

  const fetchQuotes = async () => {
    setIsLoading(true);
    setServerError(null);
    try {
      console.log('Fetching quotes from:', `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/quotes`);
      console.log('Project ID:', projectId);
      console.log('Public Anon Key:', publicAnonKey ? 'Present' : 'Missing');

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/quotes`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
          },
        }
      );

      console.log('Response status:', response.status);
      console.log('Response ok:', response.ok);

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      console.log('Quotes result:', result);

      if (result.success) {
        setQuotes(result.data || []);
      } else {
        console.error('Failed to fetch quotes:', result.error);
        setServerError(`Failed to fetch quotes: ${result.error}`);
      }
    } catch (error) {
      console.error('Error fetching quotes:', error);
      console.error('Error details:', {
        message: error.message,
        stack: error.stack,
      });
      setServerError(`Error: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  const deleteQuote = async (quoteId: string) => {
    if (!confirm('Are you sure you want to delete this quote?')) {
      return;
    }

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/quotes/${quoteId}`,
        {
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
          },
        }
      );

      const result = await response.json();
      if (result.success) {
        setQuotes(quotes.filter(q => q.id !== quoteId));
      }
    } catch (error) {
      console.error('Error deleting quote:', error);
    }
  };

  const filteredQuotes = quotes.filter(quote =>
    quote.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    quote.customerName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    quote.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(value || 0);
  };

  return (
    <div className="w-full h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <FileText className="w-8 h-8 text-blue-600" />
            <div>
              <h1 className="text-2xl font-semibold text-gray-900">All Quotes</h1>
              <p className="text-sm text-gray-500 mt-1">{quotes.length} total quotes</p>
            </div>
          </div>
          <Button onClick={onCreateNew} className="gap-2">
            <Plus className="w-4 h-4" />
            Create New Quote
          </Button>
        </div>

        {/* Search Bar */}
        <div className="mt-4 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            type="text"
            placeholder="Search quotes by ID, description, or customer name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Quote List */}
      <div className="flex-1 overflow-auto p-6">
        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <div className="text-gray-500">Loading quotes...</div>
          </div>
        ) : serverError ? (
          <div className="flex flex-col items-center justify-center h-64">
            <FileText className="w-16 h-16 text-gray-300 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {serverError}
            </h3>
            <p className="text-sm text-gray-500 mb-4">
              Please check your server configuration or try again later.
            </p>
          </div>
        ) : filteredQuotes.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64">
            <FileText className="w-16 h-16 text-gray-300 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {searchTerm ? 'No quotes found' : 'No quotes yet'}
            </h3>
            <p className="text-sm text-gray-500 mb-4">
              {searchTerm
                ? 'Try adjusting your search terms'
                : 'Create your first quote to get started'}
            </p>
            {!searchTerm && (
              <Button onClick={onCreateNew} className="gap-2">
                <Plus className="w-4 h-4" />
                Create New Quote
              </Button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
            {filteredQuotes.map((quote) => (
              <Card
                key={quote.id}
                className="p-5 hover:shadow-lg transition-shadow cursor-pointer group"
                onClick={() => onEditQuote(quote.id)}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold text-gray-900 text-lg">
                        {quote.id}
                      </h3>
                      <Badge variant="outline" className="text-xs">
                        {quote.lineItemCount || 0} items
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600 line-clamp-2">
                      {quote.description || 'No description'}
                    </p>
                  </div>
                </div>

                <div className="space-y-2 mb-4">
                  <div className="flex items-center gap-2 text-sm">
                    <span className="text-gray-500">Customer:</span>
                    <span className="font-medium text-gray-900">
                      {quote.customerName || quote.customer || 'Not specified'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="w-4 h-4 text-gray-400" />
                    <span className="text-gray-500">Created:</span>
                    <span className="text-gray-700">
                      {formatDate(quote.dateCreated)}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <span className="text-gray-500">Total Value:</span>
                    <span className="font-semibold text-green-600">
                      {formatCurrency(quote.totalValue || 0)}
                    </span>
                  </div>
                </div>

                <div className="flex gap-2 border-t border-gray-200 pt-3">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1 gap-2"
                    onClick={(e) => {
                      e.stopPropagation();
                      onEditQuote(quote.id);
                    }}
                  >
                    <Pencil className="w-3 h-3" />
                    Edit
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="gap-2 text-red-600 hover:text-red-700 hover:bg-red-50"
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteQuote(quote.id);
                    }}
                  >
                    <Trash2 className="w-3 h-3" />
                    Delete
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}