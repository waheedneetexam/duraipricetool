import React, { useState } from 'react';
import { Upload, FileUp, Check, X, AlertCircle, Download } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';

interface ColumnDefinition {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'date' | 'json' | 'text';
  required: boolean;
}

interface TableSchema {
  name: string;
  displayName: string;
  columns: ColumnDefinition[];
  primaryKey: string;
}

interface CsvDataImporterProps {
  table: TableSchema;
  onCancel: () => void;
  onImport: (data: any[]) => Promise<void>;
}

export function CsvDataImporter({ table, onCancel, onImport }: CsvDataImporterProps) {
  const [csvData, setCsvData] = useState<any[]>([]);
  const [csvHeaders, setCsvHeaders] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [step, setStep] = useState<1 | 2>(1);
  const [isImporting, setIsImporting] = useState(false);

  const parseCsv = (csvText: string): { headers: string[]; data: any[] } => {
    const lines = csvText.trim().split('\n');
    if (lines.length < 2) {
      throw new Error('CSV must have at least a header row and one data row');
    }

    const headers = lines[0].split(',').map(h => h.trim());
    const data: any[] = [];

    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(',').map(v => v.trim());
      const row: any = {};
      headers.forEach((header, index) => {
        row[header] = values[index] || '';
      });
      data.push(row);
    }

    return { headers, data };
  };

  const convertValue = (value: string, type: string): any => {
    if (value === '' || value === null || value === undefined) {
      return null;
    }

    switch (type) {
      case 'number':
        return parseFloat(value);
      case 'boolean':
        return value.toLowerCase() === 'true';
      case 'json':
        try {
          return JSON.parse(value);
        } catch {
          return value;
        }
      default:
        return value;
    }
  };

  const validateAndTransformData = (data: any[]): any[] => {
    return data.map((row, idx) => {
      const transformedRow: any = {};
      
      for (const column of table.columns) {
        const value = row[column.name];
        
        if (column.required && (value === undefined || value === '')) {
          throw new Error(`Row ${idx + 1}: Required column '${column.name}' is missing or empty`);
        }
        
        transformedRow[column.name] = convertValue(value, column.type);
      }
      
      return transformedRow;
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const csvText = event.target?.result as string;
        const { headers, data } = parseCsv(csvText);
        
        const missingColumns = table.columns
          .filter(col => !headers.includes(col.name))
          .map(col => col.name);
        
        if (missingColumns.length > 0) {
          throw new Error(`Missing required columns: ${missingColumns.join(', ')}`);
        }
        
        setCsvHeaders(headers);
        setCsvData(data);
        setStep(2);
        setError(null);
      } catch (err) {
        setError('Failed to parse CSV: ' + String(err));
      }
    };
    reader.readAsText(file);
  };

  const handleImport = async () => {
    try {
      setIsImporting(true);
      setError(null);
      
      const transformedData = validateAndTransformData(csvData);
      await onImport(transformedData);
      
      setSuccess(`Successfully imported ${transformedData.length} records!`);
      setTimeout(() => {
        onCancel();
      }, 2000);
    } catch (err) {
      setError('Import failed: ' + String(err));
    } finally {
      setIsImporting(false);
    }
  };

  const downloadTemplate = () => {
    const headers = table.columns.map(col => col.name).join(',');
    const sampleRow = table.columns.map(col => {
      switch (col.type) {
        case 'string': return 'sample_text';
        case 'number': return '123';
        case 'boolean': return 'true';
        case 'date': return '2024-01-01';
        case 'json': return '{"key":"value"}';
        case 'text': return 'Sample long text';
        default: return '';
      }
    }).join(',');
    
    const csvContent = `${headers}\n${sampleRow}`;
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${table.name}_template.csv`;
    a.click();
  };

  if (step === 1) {
    return (
      <div className="w-full h-full bg-gray-50 p-6 overflow-y-auto">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-semibold text-gray-900">Import Data from CSV</h2>
              <p className="text-sm text-gray-500 mt-1">
                Import data into <span className="font-medium">{table.displayName}</span>
              </p>
            </div>
            <Button variant="outline" onClick={onCancel}>
              Cancel
            </Button>
          </div>

          {error && (
            <Alert className="mb-4 border-red-200 bg-red-50">
              <AlertCircle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800">{error}</AlertDescription>
            </Alert>
          )}

          <Card className="p-8 mb-4">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <FileUp className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Upload CSV File</h3>
              <p className="text-sm text-gray-500 mb-6">
                The CSV headers must match the table column names exactly
              </p>
              
              <div className="flex gap-3 justify-center">
                <Button variant="outline" onClick={downloadTemplate} className="gap-2">
                  <Download className="w-4 h-4" />
                  Download Template
                </Button>
                
                <label>
                  <Button className="gap-2" onClick={() => document.getElementById('csv-data-input')?.click()}>
                    <Upload className="w-4 h-4" />
                    Choose CSV File
                  </Button>
                  <input
                    id="csv-data-input"
                    type="file"
                    accept=".csv"
                    className="hidden"
                    onChange={handleFileUpload}
                  />
                </label>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="font-semibold text-sm text-gray-900 mb-3">Expected Columns</h3>
            <div className="space-y-2">
              {table.columns.map((col) => (
                <div key={col.name} className="flex items-center justify-between text-sm py-2 px-3 bg-gray-50 rounded">
                  <div className="flex items-center gap-3">
                    <code className="font-mono text-xs bg-white px-2 py-1 rounded border">{col.name}</code>
                    {col.required && <span className="text-red-600 text-xs">*Required</span>}
                  </div>
                  <span className="text-gray-500 text-xs">{col.type}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full h-full bg-gray-50 p-6 overflow-y-auto">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-semibold text-gray-900">Preview & Import</h2>
            <p className="text-sm text-gray-500 mt-1">
              Review the data before importing
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onCancel}>
              Cancel
            </Button>
            <Button onClick={handleImport} disabled={isImporting}>
              {isImporting ? 'Importing...' : `Import ${csvData.length} Records`}
            </Button>
          </div>
        </div>

        {error && (
          <Alert className="mb-4 border-red-200 bg-red-50">
            <AlertCircle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-800">{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="mb-4 border-green-200 bg-green-50">
            <Check className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-green-800">{success}</AlertDescription>
          </Alert>
        )}

        <Card className="p-6 mb-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-900">Import Summary</h3>
            <div className="text-sm text-gray-500">
              {csvData.length} rows found
            </div>
          </div>
          <div className="grid grid-cols-3 gap-4 text-sm">
            <div className="bg-blue-50 rounded p-3">
              <p className="text-gray-600 text-xs">Total Records</p>
              <p className="text-2xl font-bold text-blue-600">{csvData.length}</p>
            </div>
            <div className="bg-green-50 rounded p-3">
              <p className="text-gray-600 text-xs">Columns Matched</p>
              <p className="text-2xl font-bold text-green-600">{table.columns.length}</p>
            </div>
            <div className="bg-purple-50 rounded p-3">
              <p className="text-gray-600 text-xs">Required Fields</p>
              <p className="text-2xl font-bold text-purple-600">
                {table.columns.filter(c => c.required).length}
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-4">
          <h3 className="font-semibold text-sm text-gray-900 mb-3">Data Preview (First 10 rows)</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-gray-100">
                <tr>
                  {table.columns.map((column) => (
                    <th key={column.name} className="px-3 py-2 text-left font-semibold text-gray-700">
                      {column.name}
                      {column.required && <span className="text-red-500 ml-1">*</span>}
                      <div className="text-xs text-gray-400 font-normal">({column.type})</div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {csvData.slice(0, 10).map((row, idx) => (
                  <tr key={idx} className="hover:bg-gray-50">
                    {table.columns.map((column) => (
                      <td key={column.name} className="px-3 py-2 text-gray-900">
                        {row[column.name] !== undefined ? row[column.name] : (
                          <span className="text-red-500 text-xs">MISSING</span>
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
}
