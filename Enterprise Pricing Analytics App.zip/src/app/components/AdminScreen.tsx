import React, { useState } from 'react';
import { Upload, Database, FileText, Download, CheckCircle, AlertCircle, Zap, Table, Settings2, Sparkles, Code } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Alert, AlertDescription } from './ui/alert';
import { projectId, publicAnonKey } from '/utils/supabase/info';
import { TableManager } from './TableManager';
import { LineItemConfigurator } from './LineItemConfigurator';
import { AIPricingEngine } from './AIPricingEngine';
import { FieldLogicManager } from './FieldLogicManager';

interface ImportResult {
  success: boolean;
  count?: number;
  error?: string;
}

interface MasterDataTable {
  id: string;
  name: string;
  endpoint: string;
  fields: string[];
  sampleCsv: string;
}

const MASTER_DATA_TABLES: MasterDataTable[] = [
  {
    id: 'product-hierarchies',
    name: 'Product Hierarchies',
    endpoint: 'product-hierarchies',
    fields: ['id', 'name', 'description'],
    sampleCsv: 'id,name,description\nsoftware,Software Solutions,Enterprise software products\nhardware,Hardware Products,Physical hardware devices',
  },
  {
    id: 'customers',
    name: 'Customers',
    endpoint: 'customers',
    fields: ['id', 'name', 'type', 'region', 'country'],
    sampleCsv: 'id,name,type,region,country\nacme-corp,Acme Corporation,Enterprise,North America,US\ntechstart-inc,TechStart Inc.,Mid-Market,North America,US',
  },
  {
    id: 'sales-orgs',
    name: 'Sales Organizations',
    endpoint: 'sales-orgs',
    fields: ['id', 'name', 'region'],
    sampleCsv: 'id,name,region\nus-east,US East,North America\nus-west,US West,North America\nemea,EMEA,Europe',
  },
  {
    id: 'regions',
    name: 'Regions',
    endpoint: 'regions',
    fields: ['id', 'name'],
    sampleCsv: 'id,name\nnorth-america,North America\neurope,Europe\nasia-pacific,Asia Pacific',
  },
  {
    id: 'countries',
    name: 'Countries',
    endpoint: 'countries',
    fields: ['id', 'name', 'code', 'region'],
    sampleCsv: 'id,name,code,region\nus,United States,US,north-america\nuk,United Kingdom,GB,europe\nde,Germany,DE,europe',
  },
  {
    id: 'currencies',
    name: 'Currencies',
    endpoint: 'currencies',
    fields: ['id', 'code', 'name', 'symbol'],
    sampleCsv: 'id,code,name,symbol\nusd,USD,US Dollar,$\neur,EUR,Euro,€\ngbp,GBP,British Pound,£',
  },
  {
    id: 'price-lists',
    name: 'Price Lists',
    endpoint: 'price-lists',
    fields: ['id', 'name', 'type', 'validFrom', 'validTo'],
    sampleCsv: 'id,name,type,validFrom,validTo\nstandard,Standard Price List,Standard,2024-01-01,2024-12-31\nenterprise,Enterprise Price List,Enterprise,2024-01-01,2024-12-31',
  },
  {
    id: 'payment-terms',
    name: 'Payment Terms',
    endpoint: 'payment-terms',
    fields: ['id', 'name', 'days', 'description'],
    sampleCsv: 'id,name,days,description\nnet-30,Net 30,30,Payment due within 30 days\nnet-60,Net 60,60,Payment due within 60 days',
  },
  {
    id: 'products',
    name: 'Products',
    endpoint: 'products',
    fields: ['id', 'sku', 'productName', 'listPrice', 'cost', 'category', 'description'],
    sampleCsv: 'id,sku,productName,listPrice,cost,category,description\n1,ESL-2024-001,Enterprise Software License,299.99,150.00,Software,Annual enterprise license\n2,PSP-2024-002,Premium Support Package,99.99,40.00,Services,24/7 premium support',
  },
];

export function AdminScreen() {
  const [selectedTable, setSelectedTable] = useState<MasterDataTable>(MASTER_DATA_TABLES[0]);
  const [importResults, setImportResults] = useState<Record<string, ImportResult>>({});
  const [isImporting, setIsImporting] = useState(false);
  const [showTableManager, setShowTableManager] = useState(false);
  const [showLineItemConfigurator, setShowLineItemConfigurator] = useState(false);
  const [showAIPricingEngine, setShowAIPricingEngine] = useState(false);
  const [showFieldLogicManager, setShowFieldLogicManager] = useState(false);

  if (showTableManager) {
    return <TableManager onBack={() => setShowTableManager(false)} />;
  }

  if (showLineItemConfigurator) {
    return <LineItemConfigurator onBack={() => setShowLineItemConfigurator(false)} />;
  }

  if (showAIPricingEngine) {
    return <AIPricingEngine onBack={() => setShowAIPricingEngine(false)} />;
  }

  if (showFieldLogicManager) {
    return <FieldLogicManager onBack={() => setShowFieldLogicManager(false)} />;
  }

  const parseCsv = (csvText: string): any[] => {
    const lines = csvText.trim().split('\n');
    if (lines.length < 2) {
      throw new Error('CSV must have at least a header row and one data row');
    }

    const headers = lines[0].split(',').map(h => h.trim());
    const data = [];

    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(',').map(v => v.trim());
      const obj: any = {};
      
      headers.forEach((header, index) => {
        const value = values[index];
        // Try to parse numbers
        if (header === 'listPrice' || header === 'cost' || header === 'days') {
          obj[header] = parseFloat(value) || 0;
        } else {
          obj[header] = value;
        }
      });
      
      data.push(obj);
    }

    return data;
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>, table: MasterDataTable) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsImporting(true);
    try {
      const text = await file.text();
      const data = parseCsv(text);

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/${table.endpoint}/import`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({ data }),
        }
      );

      const result = await response.json();
      
      setImportResults(prev => ({
        ...prev,
        [table.id]: result,
      }));

      // Clear the file input
      event.target.value = '';
    } catch (error) {
      console.error(`Error importing ${table.name}:`, error);
      setImportResults(prev => ({
        ...prev,
        [table.id]: {
          success: false,
          error: error instanceof Error ? error.message : String(error),
        },
      }));
    } finally {
      setIsImporting(false);
    }
  };

  const downloadSampleCsv = (table: MasterDataTable) => {
    const blob = new Blob([table.sampleCsv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${table.id}-sample.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="w-full h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Database className="w-8 h-8 text-blue-600" />
            <div>
              <h1 className="text-2xl font-semibold text-gray-900">Data Management Admin</h1>
              <p className="text-sm text-gray-500 mt-1">Import master data via CSV files & configure line items</p>
            </div>
          </div>
          <div className="flex gap-2">
            <Button 
              onClick={() => setShowTableManager(true)}
              className="gap-2 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            >
              <Zap className="w-4 h-4" />
              Table Manager
            </Button>
            <Button 
              onClick={() => setShowLineItemConfigurator(true)}
              className="gap-2 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            >
              <Settings2 className="w-4 h-4" />
              Line Item Configurator
            </Button>
            <Button 
              onClick={() => setShowAIPricingEngine(true)}
              className="gap-2 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            >
              <Sparkles className="w-4 h-4" />
              AI Pricing Engine
            </Button>
            <Button 
              onClick={() => setShowFieldLogicManager(true)}
              className="gap-2 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            >
              <Code className="w-4 h-4" />
              Field Logic Manager
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto p-6">
        <Tabs defaultValue={selectedTable.id} className="w-full" onValueChange={(value) => {
          const table = MASTER_DATA_TABLES.find(t => t.id === value);
          if (table) setSelectedTable(table);
        }}>
          <TabsList className="grid grid-cols-5 lg:grid-cols-9 gap-2 h-auto p-2 bg-white">
            {MASTER_DATA_TABLES.map(table => (
              <TabsTrigger 
                key={table.id} 
                value={table.id}
                className="text-xs py-2 px-3"
              >
                {table.name}
              </TabsTrigger>
            ))}
          </TabsList>

          {MASTER_DATA_TABLES.map(table => (
            <TabsContent key={table.id} value={table.id} className="mt-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Import Section */}
                <Card className="p-6">
                  <div className="flex items-center gap-2 mb-4">
                    <Upload className="w-5 h-5 text-blue-600" />
                    <h2 className="text-lg font-semibold text-gray-900">Import {table.name}</h2>
                  </div>
                  
                  <p className="text-sm text-gray-600 mb-4">
                    Upload a CSV file to import {table.name.toLowerCase()} data into the system.
                  </p>

                  <div className="space-y-4">
                    <div>
                      <h3 className="text-sm font-medium text-gray-900 mb-2">Required Fields:</h3>
                      <div className="flex flex-wrap gap-2">
                        {table.fields.map(field => (
                          <span key={field} className="px-2 py-1 bg-blue-50 text-blue-700 text-xs rounded-md font-mono">
                            {field}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
                      <input
                        type="file"
                        accept=".csv"
                        onChange={(e) => handleFileUpload(e, table)}
                        className="hidden"
                        id={`file-upload-${table.id}`}
                        disabled={isImporting}
                      />
                      <label
                        htmlFor={`file-upload-${table.id}`}
                        className="cursor-pointer"
                      >
                        <FileText className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                        <p className="text-sm text-gray-600 mb-1">
                          {isImporting ? 'Importing...' : 'Click to upload CSV file'}
                        </p>
                        <p className="text-xs text-gray-500">
                          or drag and drop
                        </p>
                      </label>
                    </div>

                    {importResults[table.id] && (
                      <Alert className={importResults[table.id].success ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}>
                        {importResults[table.id].success ? (
                          <CheckCircle className="h-4 w-4 text-green-600" />
                        ) : (
                          <AlertCircle className="h-4 w-4 text-red-600" />
                        )}
                        <AlertDescription className={importResults[table.id].success ? 'text-green-800' : 'text-red-800'}>
                          {importResults[table.id].success 
                            ? `Successfully imported ${importResults[table.id].count} records`
                            : `Error: ${importResults[table.id].error}`
                          }
                        </AlertDescription>
                      </Alert>
                    )}
                  </div>
                </Card>

                {/* Sample CSV Section */}
                <Card className="p-6">
                  <div className="flex items-center gap-2 mb-4">
                    <Download className="w-5 h-5 text-green-600" />
                    <h2 className="text-lg font-semibold text-gray-900">Sample CSV Template</h2>
                  </div>
                  
                  <p className="text-sm text-gray-600 mb-4">
                    Download a sample CSV file to see the correct format.
                  </p>

                  <div className="bg-gray-900 rounded-lg p-4 mb-4 overflow-x-auto">
                    <pre className="text-xs text-green-400 font-mono">
                      {table.sampleCsv}
                    </pre>
                  </div>

                  <Button 
                    onClick={() => downloadSampleCsv(table)}
                    variant="outline"
                    className="w-full gap-2"
                  >
                    <Download className="w-4 h-4" />
                    Download Sample CSV
                  </Button>

                  <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                    <h3 className="text-sm font-medium text-blue-900 mb-2">Import Instructions:</h3>
                    <ul className="text-xs text-blue-800 space-y-1 list-disc list-inside">
                      <li>First row must contain column headers</li>
                      <li>All required fields must be present</li>
                      <li>Use comma (,) as the delimiter</li>
                      <li>Numeric fields will be automatically parsed</li>
                      <li>Existing records with the same ID will be updated</li>
                    </ul>
                  </div>
                </Card>
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </div>
  );
}