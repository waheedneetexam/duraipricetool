import React, { useState, useEffect } from 'react';
import { 
  Sparkles, Upload, Download, Settings, Play, CheckCircle, 
  AlertCircle, ArrowLeft, FileText, Zap, RefreshCw, Code,
  Brain, BookOpen, Lightbulb, Save
} from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Alert, AlertDescription } from './ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { projectId, publicAnonKey } from '/utils/supabase/info';

interface AIPricingEngineProps {
  onBack: () => void;
}

interface ProcessingResult {
  success: boolean;
  headerFields?: any[];
  lineItemFields?: any[];
  calculationRules?: any[];
  error?: string;
  aiExplanation?: string;
}

const TEMPLATE_EXAMPLE = `# AI PRICING ENGINE - REQUIREMENTS TEMPLATE
# Fill out this template with your pricing logic and business rules

## COMPANY INFORMATION
company_name: "Acme Corporation"
industry: "Enterprise Software"
pricing_model: "Subscription + Usage-based"

## QUOTE HEADER CONFIGURATION
header_fields:
  - name: "customer_segment"
    type: "select"
    options: ["Enterprise", "Mid-Market", "SMB"]
    required: true
    description: "Customer segment determines base discount tier"
  
  - name: "deal_size"
    type: "currency"
    calculated: true
    description: "Sum of all line item totals"
  
  - name: "total_discount_percent"
    type: "percent"
    calculated: true
    description: "Weighted average discount across all line items"
  
  - name: "payment_terms"
    type: "select"
    options: ["Net 30", "Net 60", "Net 90", "Upfront"]
    default: "Net 30"

## LINE ITEM CONFIGURATION
line_item_fields:
  - name: "product_sku"
    type: "string"
    required: true
  
  - name: "quantity"
    type: "number"
    required: true
    min: 1
  
  - name: "list_price"
    type: "currency"
    required: true
  
  - name: "volume_discount_percent"
    type: "percent"
    calculated: true
    description: "Discount based on quantity tiers"
  
  - name: "segment_discount_percent"
    type: "percent"
    calculated: true
    description: "Discount based on customer segment"
  
  - name: "final_unit_price"
    type: "currency"
    calculated: true
  
  - name: "extended_price"
    type: "currency"
    calculated: true
  
  - name: "cost"
    type: "currency"
    required: true
  
  - name: "margin_percent"
    type: "percent"
    calculated: true
  
  - name: "margin_amount"
    type: "currency"
    calculated: true

## PRICING LOGIC & BUSINESS RULES

### Volume Discount Rules
volume_discounts:
  rule: "Quantity-based tiered discounts"
  tiers:
    - quantity_from: 1
      quantity_to: 10
      discount: 0
    - quantity_from: 11
      quantity_to: 50
      discount: 5
    - quantity_from: 51
      quantity_to: 100
      discount: 10
    - quantity_from: 101
      quantity_to: null  # null means infinity
      discount: 15

### Customer Segment Discounts
segment_discounts:
  rule: "Additional discount based on customer segment"
  Enterprise: 10
  Mid-Market: 5
  SMB: 0

### Price Calculation Logic
price_calculation:
  step_1: "Apply volume discount to list price"
  formula_1: "discounted_price = list_price * (1 - volume_discount_percent / 100)"
  
  step_2: "Apply segment discount to discounted price"
  formula_2: "final_unit_price = discounted_price * (1 - segment_discount_percent / 100)"
  
  step_3: "Calculate extended price"
  formula_3: "extended_price = final_unit_price * quantity"
  
  step_4: "Calculate margin"
  formula_4: "total_cost = cost * quantity"
  formula_5: "margin_amount = extended_price - total_cost"
  formula_6: "margin_percent = (margin_amount / extended_price) * 100"

### Header Calculation Logic
header_calculations:
  deal_size:
    description: "Sum of all line item extended prices"
    formula: "SUM(line_items.extended_price)"
  
  total_discount_percent:
    description: "Weighted average discount"
    formula: "WEIGHTED_AVG(line_items.volume_discount_percent + line_items.segment_discount_percent, line_items.extended_price)"

### Business Validation Rules
validation_rules:
  - rule: "Minimum margin requirement"
    condition: "margin_percent >= 20"
    error_message: "Margin must be at least 20%"
    level: "warning"
  
  - rule: "Maximum total discount"
    condition: "(volume_discount_percent + segment_discount_percent) <= 25"
    error_message: "Total discount cannot exceed 25%"
    level: "error"
  
  - rule: "Deal size minimum for Enterprise"
    condition: "IF customer_segment = 'Enterprise' THEN deal_size >= 50000"
    error_message: "Enterprise deals must be at least $50,000"
    level: "warning"

### Approval Workflow Rules
approval_rules:
  - condition: "margin_percent < 25"
    approver: "Sales Manager"
    reason: "Low margin approval required"
  
  - condition: "deal_size > 100000"
    approver: "VP of Sales"
    reason: "Large deal approval required"
  
  - condition: "total_discount_percent > 20"
    approver: "Pricing Manager"
    reason: "High discount approval required"

## ADDITIONAL CONTEXT
business_context: |
  We sell enterprise software with tiered pricing. Larger deals get better discounts.
  Enterprise customers typically buy in bulk and get preferential pricing.
  We need to maintain minimum 20% margins but can flex to 15% for strategic deals.
  Payment terms affect cash flow - upfront payment may justify additional discounts.

special_instructions: |
  - Ensure all calculations round to 2 decimal places for currency
  - Discount percentages should be displayed without decimal places
  - Flag any deal with margin below 20% for manager review
  - Auto-populate cost from product catalog when available
`;

export function AIPricingEngine({ onBack }: AIPricingEngineProps) {
  const [requirements, setRequirements] = useState(TEMPLATE_EXAMPLE);
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<ProcessingResult | null>(null);
  const [activeTab, setActiveTab] = useState('template');
  const [apiKey, setApiKey] = useState('');
  const [hasApiKey, setHasApiKey] = useState(false);

  useEffect(() => {
    checkApiKey();
  }, []);

  const checkApiKey = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/ai-pricing/check-api-key`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
          },
        }
      );
      const data = await response.json();
      setHasApiKey(data.hasApiKey);
    } catch (error) {
      console.error('Error checking API key:', error);
    }
  };

  const saveApiKey = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/ai-pricing/set-api-key`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({ apiKey }),
        }
      );
      const data = await response.json();
      if (data.success) {
        setHasApiKey(true);
        alert('API key saved successfully!');
      }
    } catch (error) {
      console.error('Error saving API key:', error);
      alert('Failed to save API key');
    }
  };

  const processRequirements = async () => {
    if (!hasApiKey) {
      alert('Please configure your OpenAI API key first');
      setActiveTab('settings');
      return;
    }

    setIsProcessing(true);
    setResult(null);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/ai-pricing/process`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({ requirements }),
        }
      );

      const data = await response.json();
      setResult(data);

      if (data.success) {
        setActiveTab('results');
      }
    } catch (error) {
      console.error('Error processing requirements:', error);
      setResult({
        success: false,
        error: error instanceof Error ? error.message : String(error),
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const applyConfiguration = async () => {
    if (!result?.success) return;

    try {
      // Apply header fields configuration
      if (result.headerFields) {
        await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/config/header-fields`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${publicAnonKey}`,
            },
            body: JSON.stringify({ fields: result.headerFields }),
          }
        );
      }

      // Apply line item fields configuration
      if (result.lineItemFields) {
        await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/config/line-item-fields`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${publicAnonKey}`,
            },
            body: JSON.stringify(result.lineItemFields),
          }
        );
      }

      // Save calculation rules
      if (result.calculationRules) {
        await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/ai-pricing/rules`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${publicAnonKey}`,
            },
            body: JSON.stringify({ rules: result.calculationRules }),
          }
        );
      }

      alert('Configuration applied successfully! Your quote system is now ready to use.');
    } catch (error) {
      console.error('Error applying configuration:', error);
      alert('Failed to apply configuration');
    }
  };

  const downloadTemplate = () => {
    const blob = new Blob([TEMPLATE_EXAMPLE], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'pricing-requirements-template.yaml';
    a.click();
    URL.revokeObjectURL(url);
  };

  const uploadTemplate = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setRequirements(content);
      setActiveTab('template');
    };
    reader.readAsText(file);
  };

  return (
    <div className="w-full h-screen flex flex-col bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={onBack} className="gap-2">
              <ArrowLeft className="w-4 h-4" />
              Back
            </Button>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-blue-600 rounded-xl flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                  AI Pricing Engine
                </h1>
                <p className="text-sm text-gray-500 mt-1">
                  Next-generation intelligent pricing configuration powered by AI
                </p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              onClick={processRequirements}
              disabled={isProcessing || !hasApiKey}
              className="gap-2 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            >
              {isProcessing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <Brain className="w-4 h-4" />
                  Process with AI
                </>
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto p-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full max-w-2xl grid-cols-4 mb-6">
            <TabsTrigger value="guide" className="gap-2">
              <BookOpen className="w-4 h-4" />
              Guide
            </TabsTrigger>
            <TabsTrigger value="template" className="gap-2">
              <FileText className="w-4 h-4" />
              Template
            </TabsTrigger>
            <TabsTrigger value="results" className="gap-2">
              <Zap className="w-4 h-4" />
              Results
            </TabsTrigger>
            <TabsTrigger value="settings" className="gap-2">
              <Settings className="w-4 h-4" />
              Settings
            </TabsTrigger>
          </TabsList>

          {/* Guide Tab */}
          <TabsContent value="guide" className="space-y-6">
            <Card className="p-6 border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-blue-50">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Lightbulb className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-2">
                    How It Works
                  </h2>
                  <p className="text-gray-600 mb-4">
                    The AI Pricing Engine uses advanced language models to understand your pricing requirements
                    and automatically configure your quote system.
                  </p>
                </div>
              </div>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                    <span className="text-blue-600 font-bold">1</span>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900">Fill Template</h3>
                </div>
                <p className="text-sm text-gray-600">
                  Download the template and describe your pricing logic, business rules, 
                  discount tiers, and calculation formulas in plain language.
                </p>
              </Card>

              <Card className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                    <span className="text-purple-600 font-bold">2</span>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900">AI Processing</h3>
                </div>
                <p className="text-sm text-gray-600">
                  Our AI analyzes your requirements, interprets the pricing logic, 
                  and generates field configurations and calculation rules.
                </p>
              </Card>

              <Card className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                    <span className="text-green-600 font-bold">3</span>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900">Review & Apply</h3>
                </div>
                <p className="text-sm text-gray-600">
                  Review the generated configuration with AI-powered explanations, 
                  then apply it to your quote system with one click.
                </p>
              </Card>

              <Card className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center">
                    <span className="text-indigo-600 font-bold">4</span>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900">Start Quoting</h3>
                </div>
                <p className="text-sm text-gray-600">
                  Your quote system is now configured and ready! Create quotes with 
                  automatic pricing calculations based on your rules.
                </p>
              </Card>
            </div>

            <Card className="p-6 bg-amber-50 border-amber-200">
              <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-amber-600" />
                What You Can Define
              </h3>
              <ul className="space-y-2 text-sm text-gray-700">
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                  <span><strong>Field Configurations:</strong> Header and line item fields with types, validations, and defaults</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                  <span><strong>Pricing Logic:</strong> Volume discounts, segment pricing, promotional rules</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                  <span><strong>Calculations:</strong> Price formulas, margin calculations, aggregations</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                  <span><strong>Validation Rules:</strong> Business constraints, minimum margins, approval thresholds</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                  <span><strong>Workflow Rules:</strong> Approval requirements based on deal characteristics</span>
                </li>
              </ul>
            </Card>
          </TabsContent>

          {/* Template Tab */}
          <TabsContent value="template" className="space-y-4">
            <Card className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-lg font-semibold text-gray-900">Pricing Requirements Template</h2>
                  <p className="text-sm text-gray-500 mt-1">
                    Edit the template below with your specific pricing requirements
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={downloadTemplate} className="gap-2">
                    <Download className="w-4 h-4" />
                    Download Template
                  </Button>
                  <label>
                    <Button variant="outline" size="sm" className="gap-2" asChild>
                      <span>
                        <Upload className="w-4 h-4" />
                        Upload File
                      </span>
                    </Button>
                    <input
                      type="file"
                      accept=".yaml,.yml,.txt"
                      className="hidden"
                      onChange={uploadTemplate}
                    />
                  </label>
                </div>
              </div>

              <div className="relative">
                <Textarea
                  value={requirements}
                  onChange={(e) => setRequirements(e.target.value)}
                  className="font-mono text-xs h-[600px] bg-gray-900 text-green-400 border-gray-700"
                  placeholder="Paste your pricing requirements here..."
                />
              </div>

              <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                <h3 className="text-sm font-semibold text-blue-900 mb-2">Template Tips:</h3>
                <ul className="text-xs text-blue-800 space-y-1">
                  <li>• Use clear, descriptive names for fields and rules</li>
                  <li>• Define calculation logic step-by-step with formulas</li>
                  <li>• Include business context to help AI understand your needs</li>
                  <li>• Specify validation rules to ensure data quality</li>
                  <li>• Document special cases and edge conditions</li>
                </ul>
              </div>
            </Card>
          </TabsContent>

          {/* Results Tab */}
          <TabsContent value="results" className="space-y-4">
            {result ? (
              <>
                {result.success ? (
                  <>
                    <Alert className="border-green-200 bg-green-50">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <AlertDescription className="text-green-800">
                        <strong>Success!</strong> Your pricing requirements have been processed by AI. 
                        Review the configuration below and apply it to your quote system.
                      </AlertDescription>
                    </Alert>

                    {result.aiExplanation && (
                      <Card className="p-6 bg-gradient-to-br from-purple-50 to-blue-50 border-purple-200">
                        <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                          <Brain className="w-5 h-5 text-purple-600" />
                          AI Analysis
                        </h3>
                        <p className="text-sm text-gray-700 whitespace-pre-wrap">{result.aiExplanation}</p>
                      </Card>
                    )}

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      {result.headerFields && result.headerFields.length > 0 && (
                        <Card className="p-6">
                          <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                            <FileText className="w-5 h-5 text-blue-600" />
                            Header Fields ({result.headerFields.length})
                          </h3>
                          <div className="space-y-3">
                            {result.headerFields.map((field: any, idx: number) => (
                              <div key={idx} className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                                <div className="flex items-center justify-between mb-1">
                                  <span className="font-medium text-sm">{field.displayName || field.name}</span>
                                  <span className="text-xs px-2 py-1 bg-blue-100 text-blue-700 rounded">
                                    {field.type}
                                  </span>
                                </div>
                                {field.description && (
                                  <p className="text-xs text-gray-600 mt-1">{field.description}</p>
                                )}
                                {field.calculated && (
                                  <div className="mt-2 text-xs text-purple-600 flex items-center gap-1">
                                    <Zap className="w-3 h-3" />
                                    Auto-calculated
                                  </div>
                                )}
                              </div>
                            ))}
                          </div>
                        </Card>
                      )}

                      {result.lineItemFields && result.lineItemFields.length > 0 && (
                        <Card className="p-6">
                          <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                            <FileText className="w-5 h-5 text-green-600" />
                            Line Item Fields ({result.lineItemFields.length})
                          </h3>
                          <div className="space-y-3">
                            {result.lineItemFields.map((field: any, idx: number) => (
                              <div key={idx} className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                                <div className="flex items-center justify-between mb-1">
                                  <span className="font-medium text-sm">{field.displayName || field.name}</span>
                                  <span className="text-xs px-2 py-1 bg-green-100 text-green-700 rounded">
                                    {field.type}
                                  </span>
                                </div>
                                {field.description && (
                                  <p className="text-xs text-gray-600 mt-1">{field.description}</p>
                                )}
                                {field.calculated && (
                                  <div className="mt-2 text-xs text-purple-600 flex items-center gap-1">
                                    <Zap className="w-3 h-3" />
                                    Auto-calculated
                                  </div>
                                )}
                              </div>
                            ))}
                          </div>
                        </Card>
                      )}
                    </div>

                    {result.calculationRules && result.calculationRules.length > 0 && (
                      <Card className="p-6">
                        <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                          <Code className="w-5 h-5 text-purple-600" />
                          Calculation Rules ({result.calculationRules.length})
                        </h3>
                        <div className="space-y-3">
                          {result.calculationRules.map((rule: any, idx: number) => (
                            <div key={idx} className="p-4 bg-gray-50 rounded-lg border border-gray-200">
                              <div className="flex items-start gap-3">
                                <div className="w-6 h-6 bg-purple-100 rounded flex items-center justify-center flex-shrink-0">
                                  <span className="text-purple-600 text-xs font-bold">{idx + 1}</span>
                                </div>
                                <div className="flex-1">
                                  <h4 className="font-medium text-sm mb-1">{rule.name}</h4>
                                  {rule.description && (
                                    <p className="text-xs text-gray-600 mb-2">{rule.description}</p>
                                  )}
                                  {rule.formula && (
                                    <code className="text-xs bg-gray-800 text-green-400 px-2 py-1 rounded block mt-2">
                                      {rule.formula}
                                    </code>
                                  )}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </Card>
                    )}

                    <div className="flex justify-center">
                      <Button
                        onClick={applyConfiguration}
                        size="lg"
                        className="gap-2 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                      >
                        <CheckCircle className="w-5 h-5" />
                        Apply Configuration to Quote System
                      </Button>
                    </div>
                  </>
                ) : (
                  <Alert className="border-red-200 bg-red-50">
                    <AlertCircle className="h-4 w-4 text-red-600" />
                    <AlertDescription className="text-red-800">
                      <strong>Error:</strong> {result.error}
                    </AlertDescription>
                  </Alert>
                )}
              </>
            ) : (
              <Card className="p-12 text-center">
                <Brain className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-500 mb-2">No Results Yet</h3>
                <p className="text-sm text-gray-400">
                  Fill out the template and click "Process with AI" to see results
                </p>
              </Card>
            )}
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-4">
            <Card className="p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">AI Configuration</h2>
              
              <Alert className={hasApiKey ? "border-green-200 bg-green-50 mb-4" : "border-amber-200 bg-amber-50 mb-4"}>
                {hasApiKey ? (
                  <>
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <AlertDescription className="text-green-800">
                      OpenAI API key is configured and ready to use.
                    </AlertDescription>
                  </>
                ) : (
                  <>
                    <AlertCircle className="h-4 w-4 text-amber-600" />
                    <AlertDescription className="text-amber-800">
                      OpenAI API key is required to use the AI Pricing Engine.
                    </AlertDescription>
                  </>
                )}
              </Alert>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="api-key">OpenAI API Key</Label>
                  <p className="text-xs text-gray-500 mb-2">
                    Get your API key from{' '}
                    <a
                      href="https://platform.openai.com/api-keys"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline"
                    >
                      platform.openai.com/api-keys
                    </a>
                  </p>
                  <Input
                    id="api-key"
                    type="password"
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    placeholder="sk-..."
                    className="font-mono"
                  />
                </div>

                <Button onClick={saveApiKey} disabled={!apiKey} className="gap-2">
                  <Save className="w-4 h-4" />
                  Save API Key
                </Button>
              </div>

              <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                <h3 className="text-sm font-semibold text-blue-900 mb-2">About AI Models</h3>
                <p className="text-xs text-blue-800">
                  This system uses OpenAI's GPT-4 model to analyze your pricing requirements. 
                  The AI interprets natural language business rules and converts them into 
                  structured configurations for your quote system.
                </p>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}