import React, { useState, useEffect } from 'react';
import { 
  Database, Plus, Trash2, Eye, Table as TableIcon,  
  Edit, Save, X, ChevronRight, AlertCircle, Check, RefreshCw,
  Upload, FileUp
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';
import { projectId, publicAnonKey } from '/utils/supabase/info';
import { CsvTableImporter } from './CsvTableImporter';
import { CsvDataImporter } from './CsvDataImporter';

interface ColumnDefinition {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'date' | 'json' | 'text';
  required: boolean;
}

interface TableSchema {
  name: string;
  displayName: string;
  columns: ColumnDefinition[];
  primaryKey: string;
  createdAt: string;
}

interface TableRecord {
  [key: string]: any;
}

const DATA_TYPES = [
  { value: 'string', label: 'String', icon: 'Aa' },
  { value: 'number', label: 'Number', icon: '#' },
  { value: 'boolean', label: 'Boolean', icon: '✓' },
  { value: 'date', label: 'Date', icon: '📅' },
  { value: 'text', label: 'Text (Long)', icon: '📝' },
  { value: 'json', label: 'JSON', icon: '{}' },
];

interface TableManagerProps {
  onBack: () => void;
}

export function TableManager({ onBack }: TableManagerProps) {
  const [tables, setTables] = useState<TableSchema[]>([]);
  const [selectedTable, setSelectedTable] = useState<TableSchema | null>(null);
  const [tableData, setTableData] = useState<TableRecord[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showCreateTable, setShowCreateTable] = useState(false);
  const [showTableData, setShowTableData] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  
  // CSV import states
  const [showCsvTableImport, setShowCsvTableImport] = useState(false);
  const [showCsvDataImport, setShowCsvDataImport] = useState(false);

  // New table form
  const [newTableName, setNewTableName] = useState('');
  const [newTableDisplayName, setNewTableDisplayName] = useState('');
  const [newTableColumns, setNewTableColumns] = useState<ColumnDefinition[]>([
    { name: 'id', type: 'string', required: true }
  ]);

  // Edit record
  const [editingRecord, setEditingRecord] = useState<TableRecord | null>(null);
  const [showAddRecord, setShowAddRecord] = useState(false);
  const [newRecord, setNewRecord] = useState<TableRecord>({});

  useEffect(() => {
    loadTables();
  }, []);

  const loadTables = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/table-schemas`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
          },
        }
      );

      const result = await response.json();
      if (result.success) {
        setTables(result.data || []);
      } else {
        setError('Failed to load tables');
      }
    } catch (err) {
      console.error('Error loading tables:', err);
      setError('Failed to load tables: ' + String(err));
    } finally {
      setIsLoading(false);
    }
  };

  const loadTableData = async (table: TableSchema) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/tables/${table.name}/data`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
          },
        }
      );

      const result = await response.json();
      if (result.success) {
        setTableData(result.data || []);
        setSelectedTable(table);
        setShowTableData(true);
      } else {
        setError('Failed to load table data');
      }
    } catch (err) {
      console.error('Error loading table data:', err);
      setError('Failed to load table data: ' + String(err));
    } finally {
      setIsLoading(false);
    }
  };

  const createTable = async (name?: string, displayName?: string, columns?: ColumnDefinition[]) => {
    const tableName = name || newTableName;
    const tableDisplayName = displayName || newTableDisplayName;
    const tableColumns = columns || newTableColumns;

    if (!tableName || !tableDisplayName) {
      setError('Please provide table name and display name');
      return;
    }

    if (tableColumns.length === 0) {
      setError('Please add at least one column');
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const schema: TableSchema = {
        name: tableName.toLowerCase().replace(/\s+/g, '_'),
        displayName: tableDisplayName,
        columns: tableColumns,
        primaryKey: tableColumns[0].name,
        createdAt: new Date().toISOString(),
      };

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/table-schemas`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify(schema),
        }
      );

      const result = await response.json();
      if (result.success) {
        setSuccess('Table created successfully!');
        setShowCreateTable(false);
        setShowCsvTableImport(false);
        resetNewTableForm();
        loadTables();
        setTimeout(() => setSuccess(null), 3000);
      } else {
        setError('Failed to create table: ' + result.error);
      }
    } catch (err) {
      console.error('Error creating table:', err);
      setError('Failed to create table: ' + String(err));
    } finally {
      setIsLoading(false);
    }
  };

  const handleCsvTableCreate = async (name: string, displayName: string, columns: ColumnDefinition[], data: any[]) => {
    // First create the table
    await createTable(name, displayName, columns);
    
    // Then import the data
    if (data.length > 0) {
      await handleCsvDataImport(data, name);
    }
  };

  const handleCsvDataImport = async (data: any[], tableName?: string) => {
    const targetTable = tableName || selectedTable?.name;
    if (!targetTable) {
      setError('No table selected');
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      // Import each record
      for (const record of data) {
        await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/tables/${targetTable}/data`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${publicAnonKey}`,
            },
            body: JSON.stringify(record),
          }
        );
      }

      setSuccess(`Successfully imported ${data.length} records!`);
      setShowCsvDataImport(false);
      if (selectedTable) {
        loadTableData(selectedTable);
      }
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      console.error('Error importing data:', err);
      setError('Failed to import data: ' + String(err));
    } finally {
      setIsLoading(false);
    }
  };

  const deleteTable = async (tableName: string) => {
    if (!confirm(`Are you sure you want to delete table "${tableName}"? This will delete all data in the table.`)) {
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/table-schemas/${tableName}`,
        {
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
          },
        }
      );

      const result = await response.json();
      if (result.success) {
        setSuccess('Table deleted successfully!');
        if (selectedTable?.name === tableName) {
          setSelectedTable(null);
          setShowTableData(false);
        }
        loadTables();
        setTimeout(() => setSuccess(null), 3000);
      } else {
        setError('Failed to delete table');
      }
    } catch (err) {
      console.error('Error deleting table:', err);
      setError('Failed to delete table: ' + String(err));
    } finally {
      setIsLoading(false);
    }
  };

  const addRecord = async () => {
    if (!selectedTable) return;

    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/tables/${selectedTable.name}/data`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify(newRecord),
        }
      );

      const result = await response.json();
      if (result.success) {
        setSuccess('Record added successfully!');
        setShowAddRecord(false);
        setNewRecord({});
        loadTableData(selectedTable);
        setTimeout(() => setSuccess(null), 3000);
      } else {
        setError('Failed to add record: ' + result.error);
      }
    } catch (err) {
      console.error('Error adding record:', err);
      setError('Failed to add record: ' + String(err));
    } finally {
      setIsLoading(false);
    }
  };

  const updateRecord = async () => {
    if (!selectedTable || !editingRecord) return;

    setIsLoading(true);
    setError(null);
    try {
      const recordId = editingRecord[selectedTable.primaryKey];
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/tables/${selectedTable.name}/data/${recordId}`,
        {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify(editingRecord),
        }
      );

      const result = await response.json();
      if (result.success) {
        setSuccess('Record updated successfully!');
        setEditingRecord(null);
        loadTableData(selectedTable);
        setTimeout(() => setSuccess(null), 3000);
      } else {
        setError('Failed to update record');
      }
    } catch (err) {
      console.error('Error updating record:', err);
      setError('Failed to update record: ' + String(err));
    } finally {
      setIsLoading(false);
    }
  };

  const deleteRecord = async (recordId: string) => {
    if (!selectedTable) return;
    if (!confirm('Are you sure you want to delete this record?')) return;

    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/tables/${selectedTable.name}/data/${recordId}`,
        {
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
          },
        }
      );

      const result = await response.json();
      if (result.success) {
        setSuccess('Record deleted successfully!');
        loadTableData(selectedTable);
        setTimeout(() => setSuccess(null), 3000);
      } else {
        setError('Failed to delete record');
      }
    } catch (err) {
      console.error('Error deleting record:', err);
      setError('Failed to delete record: ' + String(err));
    } finally {
      setIsLoading(false);
    }
  };

  const addColumn = () => {
    setNewTableColumns([
      ...newTableColumns,
      { name: '', type: 'string', required: false }
    ]);
  };

  const updateColumn = (index: number, field: keyof ColumnDefinition, value: any) => {
    const updated = [...newTableColumns];
    updated[index] = { ...updated[index], [field]: value };
    setNewTableColumns(updated);
  };

  const removeColumn = (index: number) => {
    if (index === 0) {
      alert('Cannot remove primary key column');
      return;
    }
    setNewTableColumns(newTableColumns.filter((_, i) => i !== index));
  };

  const resetNewTableForm = () => {
    setNewTableName('');
    setNewTableDisplayName('');
    setNewTableColumns([{ name: 'id', type: 'string', required: true }]);
  };

  const renderValue = (value: any, type: string) => {
    if (value === null || value === undefined) return <span className="text-gray-400">null</span>;
    
    if (type === 'boolean') {
      return value ? <Check className="w-4 h-4 text-green-600" /> : <X className="w-4 h-4 text-red-600" />;
    }
    
    if (type === 'json') {
      return <code className="text-xs bg-gray-100 px-2 py-1 rounded">{JSON.stringify(value)}</code>;
    }
    
    if (type === 'date') {
      return new Date(value).toLocaleString();
    }
    
    return String(value);
  };

  const renderInput = (column: ColumnDefinition, value: any, onChange: (value: any) => void) => {
    switch (column.type) {
      case 'number':
        return (
          <Input
            type="number"
            value={value || ''}
            onChange={(e) => onChange(parseFloat(e.target.value))}
            placeholder={column.name}
          />
        );
      case 'boolean':
        return (
          <Select value={value?.toString()} onValueChange={(v) => onChange(v === 'true')}>
            <SelectTrigger>
              <SelectValue placeholder="Select..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="true">True</SelectItem>
              <SelectItem value="false">False</SelectItem>
            </SelectContent>
          </Select>
        );
      case 'date':
        return (
          <Input
            type="datetime-local"
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
          />
        );
      case 'text':
        return (
          <textarea
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            rows={3}
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
            placeholder={column.name}
          />
        );
      case 'json':
        return (
          <textarea
            className="w-full px-3 py-2 border border-gray-300 rounded-md font-mono text-sm"
            rows={3}
            value={typeof value === 'string' ? value : JSON.stringify(value, null, 2)}
            onChange={(e) => {
              try {
                onChange(JSON.parse(e.target.value));
              } catch {
                onChange(e.target.value);
              }
            }}
            placeholder='{"key": "value"}'
          />
        );
      default:
        return (
          <Input
            type="text"
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
            placeholder={column.name}
          />
        );
    }
  };

  // Render CSV Table Importer
  if (showCsvTableImport) {
    return (
      <CsvTableImporter
        onCancel={() => setShowCsvTableImport(false)}
        onCreate={handleCsvTableCreate}
      />
    );
  }

  // Render CSV Data Importer
  if (showCsvDataImport && selectedTable) {
    return (
      <CsvDataImporter
        table={selectedTable}
        onCancel={() => setShowCsvDataImport(false)}
        onImport={handleCsvDataImport}
      />
    );
  }

  if (showCreateTable) {
    return (
      <div className="w-full h-full bg-gray-50 p-6 overflow-y-auto">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <Button variant="ghost" onClick={() => setShowCreateTable(false)}>
                <X className="w-5 h-5" />
              </Button>
              <div>
                <h2 className="text-2xl font-semibold text-gray-900">Create New Table</h2>
                <p className="text-sm text-gray-500 mt-1">Define your table schema and columns</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setShowCreateTable(false)}>
                Cancel
              </Button>
              <Button onClick={() => createTable()} disabled={isLoading}>
                {isLoading ? 'Creating...' : 'Create Table'}
              </Button>
            </div>
          </div>

          {error && (
            <Alert className="mb-4 border-red-200 bg-red-50">
              <AlertCircle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800">{error}</AlertDescription>
            </Alert>
          )}

          <Card className="p-6 mb-4">
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium mb-2 block">Table Name (Internal)</Label>
                  <Input
                    value={newTableName}
                    onChange={(e) => setNewTableName(e.target.value)}
                    placeholder="e.g., custom_pricing_rules"
                  />
                  <p className="text-xs text-gray-500 mt-1">Used in API calls (lowercase, underscores)</p>
                </div>
                <div>
                  <Label className="text-sm font-medium mb-2 block">Display Name</Label>
                  <Input
                    value={newTableDisplayName}
                    onChange={(e) => setNewTableDisplayName(e.target.value)}
                    placeholder="e.g., Custom Pricing Rules"
                  />
                  <p className="text-xs text-gray-500 mt-1">Shown in the UI</p>
                </div>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-900">Column Definitions</h3>
              <Button variant="outline" size="sm" onClick={addColumn} className="gap-2">
                <Plus className="w-4 h-4" />
                Add Column
              </Button>
            </div>

            <div className="space-y-3">
              {newTableColumns.map((column, index) => (
                <div key={index} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <Input
                      value={column.name}
                      onChange={(e) => updateColumn(index, 'name', e.target.value)}
                      placeholder="Column name"
                      disabled={index === 0}
                    />
                  </div>
                  <div className="w-48">
                    <Select
                      value={column.type}
                      onValueChange={(v: any) => updateColumn(index, 'type', v)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {DATA_TYPES.map((dt) => (
                          <SelectItem key={dt.value} value={dt.value}>
                            {dt.icon} {dt.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <label className="flex items-center gap-2 w-32">
                    <input
                      type="checkbox"
                      checked={column.required}
                      onChange={(e) => updateColumn(index, 'required', e.target.checked)}
                      disabled={index === 0}
                      className="rounded"
                    />
                    <span className="text-sm text-gray-600">Required</span>
                  </label>
                  {index > 0 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeColumn(index)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                  {index === 0 && (
                    <div className="w-10 flex items-center justify-center">
                      <span className="text-xs text-gray-400 font-medium">PK</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    );
  }

  if (showTableData && selectedTable) {
    return (
      <div className="w-full h-full bg-gray-50 flex flex-col">
        <div className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" onClick={() => setShowTableData(false)}>
                <X className="w-5 h-5" />
              </Button>
              <div>
                <h2 className="text-2xl font-semibold text-gray-900">{selectedTable.displayName}</h2>
                <p className="text-sm text-gray-500 mt-1">
                  {tableData.length} record{tableData.length !== 1 ? 's' : ''} • Table: {selectedTable.name}
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => setShowCsvDataImport(true)} className="gap-2">
                <Upload className="w-4 h-4" />
                Import CSV
              </Button>
              <Button variant="outline" size="sm" onClick={() => loadTableData(selectedTable)} className="gap-2">
                <RefreshCw className="w-4 h-4" />
                Refresh
              </Button>
              <Button size="sm" onClick={() => {
                const record: any = {};
                selectedTable.fields?.forEach(col => {
                  if (col.type === 'boolean') record[col.name] = false;
                  else if (col.type === 'number') record[col.name] = 0;
                  else record[col.name] = '';
                });
                setNewRecord(record);
                setShowAddRecord(true);
              }} className="gap-2">
                <Plus className="w-4 h-4" />
                Add Record
              </Button>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-auto p-6">
          {error && (
            <Alert className="mb-4 border-red-200 bg-red-50">
              <AlertCircle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800">{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="mb-4 border-green-200 bg-green-50">
              <Check className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-800">{success}</AlertDescription>
            </Alert>
          )}

          {showAddRecord && (
            <Card className="p-4 mb-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-gray-900">Add New Record</h3>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => setShowAddRecord(false)}>
                    Cancel
                  </Button>
                  <Button size="sm" onClick={addRecord} disabled={isLoading}>
                    Save
                  </Button>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {selectedTable.fields?.map((column) => (
                  <div key={column.name}>
                    <Label className="text-sm mb-2 block">
                      {column.name} {column.required && <span className="text-red-500">*</span>}
                      <span className="text-gray-400 ml-2 text-xs">({column.type})</span>
                    </Label>
                    {renderInput(column, newRecord[column.name], (value) => 
                      setNewRecord({ ...newRecord, [column.name]: value })
                    )}
                  </div>
                ))}
              </div>
            </Card>
          )}

          {tableData.length === 0 ? (
            <div className="text-center py-12 text-gray-400">
              <TableIcon className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p className="text-lg font-medium">No records found</p>
              <p className="text-sm mt-2">Click "Add Record" or "Import CSV" to add data</p>
            </div>
          ) : (
            <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b border-gray-200">
                    <tr>
                      {selectedTable.fields?.map((column) => (
                        <th key={column.name} className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                          {column.name}
                          <span className="text-gray-400 ml-2 normal-case">({column.type})</span>
                        </th>
                      ))}
                      <th className="px-4 py-3 text-right text-xs font-semibold text-gray-700 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {tableData.map((record, idx) => (
                      <tr key={idx} className="hover:bg-gray-50">
                        {selectedTable.fields?.map((column) => (
                          <td key={column.name} className="px-4 py-3 text-sm text-gray-900">
                            {editingRecord && editingRecord[selectedTable.primaryKey] === record[selectedTable.primaryKey] ? (
                              renderInput(column, editingRecord[column.name], (value) =>
                                setEditingRecord({ ...editingRecord, [column.name]: value })
                              )
                            ) : (
                              renderValue(record[column.name], column.type)
                            )}
                          </td>
                        ))}
                        <td className="px-4 py-3 text-sm text-right">
                          {editingRecord && editingRecord[selectedTable.primaryKey] === record[selectedTable.primaryKey] ? (
                            <div className="flex justify-end gap-2">
                              <Button variant="ghost" size="sm" onClick={() => setEditingRecord(null)}>
                                <X className="w-4 h-4" />
                              </Button>
                              <Button variant="ghost" size="sm" onClick={updateRecord}>
                                <Save className="w-4 h-4 text-green-600" />
                              </Button>
                            </div>
                          ) : (
                            <div className="flex justify-end gap-2">
                              <Button variant="ghost" size="sm" onClick={() => setEditingRecord({ ...record })}>
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                onClick={() => deleteRecord(record[selectedTable.primaryKey])}
                                className="text-red-600 hover:text-red-700"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="w-full h-full bg-gray-50 p-6 overflow-y-auto">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Database className="w-8 h-8 text-blue-600" />
            <div>
              <h2 className="text-2xl font-semibold text-gray-900">Database Tables</h2>
              <p className="text-sm text-gray-500 mt-1">View and manage all database tables</p>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setShowCsvTableImport(true)} className="gap-2">
              <FileUp className="w-4 h-4" />
              Create from CSV
            </Button>
            <Button onClick={() => setShowCreateTable(true)} className="gap-2">
              <Plus className="w-4 h-4" />
              Create Table
            </Button>
          </div>
        </div>

        {error && (
          <Alert className="mb-4 border-red-200 bg-red-50">
            <AlertCircle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-800">{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="mb-4 border-green-200 bg-green-50">
            <Check className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-green-800">{success}</AlertDescription>
          </Alert>
        )}

        {isLoading && tables.length === 0 ? (
          <div className="text-center py-12 text-gray-400">
            <RefreshCw className="w-16 h-16 mx-auto mb-4 animate-spin" />
            <p>Loading tables...</p>
          </div>
        ) : tables.length === 0 ? (
          <Card className="p-12 text-center">
            <Database className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No Tables Found</h3>
            <p className="text-gray-500 mb-6">Create your first custom table to get started</p>
            <div className="flex gap-3 justify-center">
              <Button variant="outline" onClick={() => setShowCsvTableImport(true)} className="gap-2">
                <FileUp className="w-4 h-4" />
                Create from CSV
              </Button>
              <Button onClick={() => setShowCreateTable(true)} className="gap-2">
                <Plus className="w-4 h-4" />
                Create New Table
              </Button>
            </div>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {tables.map((table) => (
              <Card key={table.name} className="p-4 hover:shadow-lg transition-shadow cursor-pointer group">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-blue-100 rounded-lg">
                      <TableIcon className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">{table.displayName}</h3>
                      <p className="text-xs text-gray-500 mt-1">{table.name}</p>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteTable(table.name);
                    }}
                    className="opacity-0 group-hover:opacity-100 transition-opacity text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>

                <div className="space-y-2 mb-4">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Columns:</span>
                    <span className="font-medium text-gray-900">{table.fields?.length || 0}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Primary Key:</span>
                    <code className="text-xs bg-gray-100 px-2 py-1 rounded">{table.primaryKey}</code>
                  </div>
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  className="w-full gap-2"
                  onClick={() => loadTableData(table)}
                >
                  <Eye className="w-4 h-4" />
                  View Data
                  <ChevronRight className="w-4 h-4 ml-auto" />
                </Button>

                <div className="mt-3 pt-3 border-t border-gray-100">
                  <p className="text-xs text-gray-500 mb-2">Columns:</p>
                  <div className="flex flex-wrap gap-1">
                    {table.fields?.slice(0, 5).map((col) => (
                      <span key={col.name} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                        {col.name}
                      </span>
                    ))}
                    {table.fields && table.fields.length > 5 && (
                      <span className="text-xs text-gray-400 px-2 py-1">
                        +{table.fields.length - 5} more
                      </span>
                    )}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}