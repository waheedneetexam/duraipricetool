import React, { useState, useRef, useEffect } from 'react';
import { Plus, Trash2, TrendingUp, TrendingDown, Minus, ChevronDown, ChevronRight, Download, Save, ChevronUp, Maximize2, Minimize2, ArrowLeft } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { LineItemAnalytics } from './LineItemAnalytics';
import { projectId, publicAnonKey } from '/utils/supabase/info';

export interface LineItem {
  id: string;
  productName: string;
  sku: string;
  quantity: number;
  listPrice: number;
  cost: number;
  volumeDiscount: number; // percentage
  rebate: number; // flat amount
  netPrice: number;
  margin: number; // percentage
  totalValue: number;
  showAnalytics: boolean;
}

interface ColumnWidths {
  [key: string]: number;
}

export function PricingTable() {
  const [items, setItems] = useState<LineItem[]>([
    {
      id: '1',
      productName: 'Enterprise Software License',
      sku: 'ESL-2024-001',
      quantity: 100,
      listPrice: 299.99,
      cost: 150.00,
      volumeDiscount: 15,
      rebate: 500,
      netPrice: 0,
      margin: 0,
      totalValue: 0,
      showAnalytics: false,
    },
    {
      id: '2',
      productName: 'Premium Support Package',
      sku: 'PSP-2024-002',
      quantity: 100,
      listPrice: 99.99,
      cost: 40.00,
      volumeDiscount: 10,
      rebate: 200,
      netPrice: 0,
      margin: 0,
      totalValue: 0,
      showAnalytics: false,
    },
    {
      id: '3',
      productName: 'Cloud Storage (TB/month)',
      sku: 'CS-2024-003',
      quantity: 50,
      listPrice: 149.99,
      cost: 75.00,
      volumeDiscount: 20,
      rebate: 150,
      netPrice: 0,
      margin: 0,
      totalValue: 0,
      showAnalytics: false,
    },
  ]);

  const [columnWidths, setColumnWidths] = useState<ColumnWidths>({
    expand: 50,
    productName: 250,
    sku: 150,
    quantity: 120,
    listPrice: 140,
    cost: 140,
    volumeDiscount: 140,
    rebate: 140,
    netPrice: 140,
    margin: 140,
    totalValue: 160,
    actions: 100,
  });

  // Header filter states
  const [productHierarchy, setProductHierarchy] = useState('');
  const [customer, setCustomer] = useState('');
  const [salesOrg, setSalesOrg] = useState('');
  const [region, setRegion] = useState('');
  const [country, setCountry] = useState('');
  const [currency, setCurrency] = useState('USD');
  const [priceList, setPriceList] = useState('');
  const [validityDate, setValidityDate] = useState('');
  const [paymentTerms, setPaymentTerms] = useState('');

  // View state
  const [isHeaderCollapsed, setIsHeaderCollapsed] = useState(false);
  const [isTableFullscreen, setIsTableFullscreen] = useState(false);

  const [resizing, setResizing] = useState<{ column: string; startX: number; startWidth: number } | null>(null);
  const tableRef = useRef<HTMLDivElement>(null);

  // Handle mouse down on resize handle
  const handleMouseDown = (e: React.MouseEvent, column: string) => {
    e.preventDefault();
    setResizing({
      column,
      startX: e.clientX,
      startWidth: columnWidths[column],
    });
  };

  // Handle mouse move during resize
  React.useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!resizing) return;
      
      const diff = e.clientX - resizing.startX;
      const newWidth = Math.max(80, resizing.startWidth + diff);
      
      setColumnWidths((prev) => ({
        ...prev,
        [resizing.column]: newWidth,
      }));
    };

    const handleMouseUp = () => {
      setResizing(null);
    };

    if (resizing) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      document.body.style.cursor = 'col-resize';
      document.body.style.userSelect = 'none';
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
    };
  }, [resizing]);

  // Calculate derived values whenever items change
  React.useEffect(() => {
    setItems((prevItems) =>
      prevItems.map((item) => {
        const discountedPrice = item.listPrice * (1 - item.volumeDiscount / 100);
        const totalBeforeRebate = discountedPrice * item.quantity;
        const totalAfterRebate = totalBeforeRebate - item.rebate;
        const netPrice = totalAfterRebate / item.quantity;
        const totalCost = item.cost * item.quantity;
        const margin = totalCost > 0 ? ((totalAfterRebate - totalCost) / totalAfterRebate) * 100 : 0;

        return {
          ...item,
          netPrice,
          margin,
          totalValue: totalAfterRebate,
        };
      })
    );
  }, []);

  const addNewItem = () => {
    const newItem: LineItem = {
      id: Date.now().toString(),
      productName: 'New Product',
      sku: `SKU-${Date.now()}`,
      quantity: 1,
      listPrice: 0,
      cost: 0,
      volumeDiscount: 0,
      rebate: 0,
      netPrice: 0,
      margin: 0,
      totalValue: 0,
      showAnalytics: false,
    };
    setItems([...items, newItem]);
  };

  const deleteItem = (id: string) => {
    setItems(items.filter((item) => item.id !== id));
  };

  const updateItem = (id: string, field: keyof LineItem, value: any) => {
    setItems((prevItems) =>
      prevItems.map((item) => {
        if (item.id !== id) return item;

        const updated = { ...item, [field]: value };

        // Recalculate derived values
        const discountedPrice = updated.listPrice * (1 - updated.volumeDiscount / 100);
        const totalBeforeRebate = discountedPrice * updated.quantity;
        const totalAfterRebate = totalBeforeRebate - updated.rebate;
        const netPrice = updated.quantity > 0 ? totalAfterRebate / updated.quantity : 0;
        const totalCost = updated.cost * updated.quantity;
        const margin = totalAfterRebate > 0 ? ((totalAfterRebate - totalCost) / totalAfterRebate) * 100 : 0;

        return {
          ...updated,
          netPrice,
          margin,
          totalValue: totalAfterRebate,
        };
      })
    );
  };

  const toggleAnalytics = (id: string) => {
    setItems((prevItems) =>
      prevItems.map((item) =>
        item.id === id ? { ...item, showAnalytics: !item.showAnalytics } : item
      )
    );
  };

  const getTotalQuoteValue = () => {
    return items.reduce((sum, item) => sum + item.totalValue, 0);
  };

  const getAverageMargin = () => {
    const totalValue = getTotalQuoteValue();
    if (totalValue === 0) return 0;
    const weightedMarginSum = items.reduce((sum, item) => {
      return sum + (item.margin * item.totalValue);
    }, 0);
    return weightedMarginSum / totalValue;
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(value);
  };

  const formatPercent = (value: number) => {
    return `${value.toFixed(2)}%`;
  };

  const getMarginColor = (margin: number) => {
    if (margin >= 40) return 'text-green-600';
    if (margin >= 25) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getMarginIcon = (margin: number) => {
    if (margin >= 40) return <TrendingUp className="w-4 h-4" />;
    if (margin >= 25) return <Minus className="w-4 h-4" />;
    return <TrendingDown className="w-4 h-4" />;
  };

  return (
    <div className="w-full min-h-screen flex flex-col bg-gray-50">
      {/* Header */}
      {!isTableFullscreen && (
        <div className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-semibold text-gray-900">Enterprise Pricing Builder</h1>
              <p className="text-sm text-gray-500 mt-1">Create and analyze customer quotes</p>
            </div>
            <div className="flex gap-3">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setIsHeaderCollapsed(!isHeaderCollapsed)}
                className="gap-2"
              >
                {isHeaderCollapsed ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
                {isHeaderCollapsed ? 'Expand Header' : 'Collapse Header'}
              </Button>
              <Button variant="outline" className="gap-2">
                <Download className="w-4 h-4" />
                Export
              </Button>
              <Button className="gap-2">
                <Save className="w-4 h-4" />
                Save Quote
              </Button>
            </div>
          </div>

          {!isHeaderCollapsed && (
            <>
              {/* Summary Cards */}
              <div className="grid grid-cols-3 gap-4 mt-6">
                <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
                  <div className="text-sm text-blue-700 mb-1">Total Quote Value</div>
                  <div className="text-2xl font-semibold text-blue-900">
                    {formatCurrency(getTotalQuoteValue())}
                  </div>
                </div>
                <div className="bg-purple-50 rounded-lg p-4 border border-purple-200">
                  <div className="text-sm text-purple-700 mb-1">Average Margin</div>
                  <div className="text-2xl font-semibold text-purple-900">
                    {formatPercent(getAverageMargin())}
                  </div>
                </div>
                <div className="bg-gray-100 rounded-lg p-4 border border-gray-300">
                  <div className="text-sm text-gray-700 mb-1">Total Line Items</div>
                  <div className="text-2xl font-semibold text-gray-900">{items.length}</div>
                </div>
              </div>

              {/* Quote Configuration Section - 3x3 Grid */}
              <div className="mt-6 bg-gray-50 rounded-lg p-6 border border-gray-200">
                <h2 className="text-sm font-semibold text-gray-900 mb-4">Quote Configuration</h2>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="product-hierarchy" className="text-xs text-gray-700">Product Hierarchy</Label>
                    <Select value={productHierarchy} onValueChange={setProductHierarchy}>
                      <SelectTrigger id="product-hierarchy" className="h-9 bg-white">
                        <SelectValue placeholder="Select product hierarchy" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="software">Software Solutions</SelectItem>
                        <SelectItem value="hardware">Hardware Products</SelectItem>
                        <SelectItem value="services">Professional Services</SelectItem>
                        <SelectItem value="cloud">Cloud & Infrastructure</SelectItem>
                        <SelectItem value="support">Support & Maintenance</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="customer" className="text-xs text-gray-700">Customer</Label>
                    <Select value={customer} onValueChange={setCustomer}>
                      <SelectTrigger id="customer" className="h-9 bg-white">
                        <SelectValue placeholder="Select customer" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="acme-corp">Acme Corporation</SelectItem>
                        <SelectItem value="techstart-inc">TechStart Inc.</SelectItem>
                        <SelectItem value="global-systems">Global Systems Ltd.</SelectItem>
                        <SelectItem value="innovation-labs">Innovation Labs</SelectItem>
                        <SelectItem value="enterprise-solutions">Enterprise Solutions Co.</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="sales-org" className="text-xs text-gray-700">Sales Organization</Label>
                    <Select value={salesOrg} onValueChange={setSalesOrg}>
                      <SelectTrigger id="sales-org" className="h-9 bg-white">
                        <SelectValue placeholder="Select sales org" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="us-east">US East</SelectItem>
                        <SelectItem value="us-west">US West</SelectItem>
                        <SelectItem value="emea">EMEA</SelectItem>
                        <SelectItem value="apac">APAC</SelectItem>
                        <SelectItem value="latam">Latin America</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="region" className="text-xs text-gray-700">Region</Label>
                    <Select value={region} onValueChange={setRegion}>
                      <SelectTrigger id="region" className="h-9 bg-white">
                        <SelectValue placeholder="Select region" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="north-america">North America</SelectItem>
                        <SelectItem value="europe">Europe</SelectItem>
                        <SelectItem value="asia-pacific">Asia Pacific</SelectItem>
                        <SelectItem value="middle-east">Middle East</SelectItem>
                        <SelectItem value="africa">Africa</SelectItem>
                        <SelectItem value="south-america">South America</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="country" className="text-xs text-gray-700">Country</Label>
                    <Select value={country} onValueChange={setCountry}>
                      <SelectTrigger id="country" className="h-9 bg-white">
                        <SelectValue placeholder="Select country" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="us">United States</SelectItem>
                        <SelectItem value="uk">United Kingdom</SelectItem>
                        <SelectItem value="de">Germany</SelectItem>
                        <SelectItem value="fr">France</SelectItem>
                        <SelectItem value="jp">Japan</SelectItem>
                        <SelectItem value="cn">China</SelectItem>
                        <SelectItem value="in">India</SelectItem>
                        <SelectItem value="au">Australia</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="currency" className="text-xs text-gray-700">Currency</Label>
                    <Select value={currency} onValueChange={setCurrency}>
                      <SelectTrigger id="currency" className="h-9 bg-white">
                        <SelectValue placeholder="Select currency" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="USD">USD - US Dollar</SelectItem>
                        <SelectItem value="EUR">EUR - Euro</SelectItem>
                        <SelectItem value="GBP">GBP - British Pound</SelectItem>
                        <SelectItem value="JPY">JPY - Japanese Yen</SelectItem>
                        <SelectItem value="CNY">CNY - Chinese Yuan</SelectItem>
                        <SelectItem value="INR">INR - Indian Rupee</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="price-list" className="text-xs text-gray-700">Price List</Label>
                    <Select value={priceList} onValueChange={setPriceList}>
                      <SelectTrigger id="price-list" className="h-9 bg-white">
                        <SelectValue placeholder="Select price list" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="standard">Standard Price List</SelectItem>
                        <SelectItem value="enterprise">Enterprise Price List</SelectItem>
                        <SelectItem value="government">Government Price List</SelectItem>
                        <SelectItem value="education">Education Price List</SelectItem>
                        <SelectItem value="non-profit">Non-Profit Price List</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="validity-date" className="text-xs text-gray-700">Validity Date</Label>
                    <Input
                      id="validity-date"
                      type="date"
                      value={validityDate}
                      onChange={(e) => setValidityDate(e.target.value)}
                      className="h-9 bg-white"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="payment-terms" className="text-xs text-gray-700">Payment Terms</Label>
                    <Select value={paymentTerms} onValueChange={setPaymentTerms}>
                      <SelectTrigger id="payment-terms" className="h-9 bg-white">
                        <SelectValue placeholder="Select payment terms" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="net-30">Net 30</SelectItem>
                        <SelectItem value="net-60">Net 60</SelectItem>
                        <SelectItem value="net-90">Net 90</SelectItem>
                        <SelectItem value="immediate">Immediate Payment</SelectItem>
                        <SelectItem value="installments">Installment Plan</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      )}

      {/* Table Controls Bar - Sticky */}
      <div className="bg-white border-b border-gray-200 px-6 py-2 flex items-center justify-between sticky top-0 z-20">
        <div className="text-sm text-gray-600">
          {items.length} line item{items.length !== 1 ? 's' : ''} • Total: {formatCurrency(getTotalQuoteValue())}
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setIsTableFullscreen(!isTableFullscreen)}
          className="gap-2"
        >
          {isTableFullscreen ? (
            <>
              <Minimize2 className="w-4 h-4" />
              Exit Fullscreen
            </>
          ) : (
            <>
              <Maximize2 className="w-4 h-4" />
              Fullscreen Table
            </>
          )}
        </Button>
      </div>

      {/* Spreadsheet Table */}
      <div className="w-full" ref={tableRef}>
        <div className="inline-block min-w-full align-middle">
          <table className="min-w-full divide-y divide-gray-300 bg-white">
            <thead className="bg-gray-100 sticky top-[49px] z-10">
              <tr>
                <th 
                  className="py-3 px-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider relative"
                  style={{ width: `${columnWidths.expand}px` }}
                >
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-500 group"
                       onMouseDown={(e) => handleMouseDown(e, 'expand')}>
                    <div className="w-full h-full group-hover:bg-blue-500"></div>
                  </div>
                </th>
                <th 
                  className="py-3 px-4 text-left text-xs font-medium text-gray-700 uppercase tracking-wider relative"
                  style={{ width: `${columnWidths.productName}px` }}
                >
                  Product Name
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-500 group"
                       onMouseDown={(e) => handleMouseDown(e, 'productName')}>
                    <div className="w-full h-full group-hover:bg-blue-500"></div>
                  </div>
                </th>
                <th 
                  className="py-3 px-4 text-left text-xs font-medium text-gray-700 uppercase tracking-wider relative"
                  style={{ width: `${columnWidths.sku}px` }}
                >
                  SKU
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-500 group"
                       onMouseDown={(e) => handleMouseDown(e, 'sku')}>
                    <div className="w-full h-full group-hover:bg-blue-500"></div>
                  </div>
                </th>
                <th 
                  className="py-3 px-4 text-right text-xs font-medium text-gray-700 uppercase tracking-wider relative"
                  style={{ width: `${columnWidths.quantity}px` }}
                >
                  Quantity
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-500 group"
                       onMouseDown={(e) => handleMouseDown(e, 'quantity')}>
                    <div className="w-full h-full group-hover:bg-blue-500"></div>
                  </div>
                </th>
                <th 
                  className="py-3 px-4 text-right text-xs font-medium text-gray-700 uppercase tracking-wider relative"
                  style={{ width: `${columnWidths.listPrice}px` }}
                >
                  List Price
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-500 group"
                       onMouseDown={(e) => handleMouseDown(e, 'listPrice')}>
                    <div className="w-full h-full group-hover:bg-blue-500"></div>
                  </div>
                </th>
                <th 
                  className="py-3 px-4 text-right text-xs font-medium text-gray-700 uppercase tracking-wider relative"
                  style={{ width: `${columnWidths.cost}px` }}
                >
                  Cost
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-500 group"
                       onMouseDown={(e) => handleMouseDown(e, 'cost')}>
                    <div className="w-full h-full group-hover:bg-blue-500"></div>
                  </div>
                </th>
                <th 
                  className="py-3 px-4 text-right text-xs font-medium text-gray-700 uppercase tracking-wider relative"
                  style={{ width: `${columnWidths.volumeDiscount}px` }}
                >
                  Volume Disc %
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-500 group"
                       onMouseDown={(e) => handleMouseDown(e, 'volumeDiscount')}>
                    <div className="w-full h-full group-hover:bg-blue-500"></div>
                  </div>
                </th>
                <th 
                  className="py-3 px-4 text-right text-xs font-medium text-gray-700 uppercase tracking-wider relative"
                  style={{ width: `${columnWidths.rebate}px` }}
                >
                  Rebate
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-500 group"
                       onMouseDown={(e) => handleMouseDown(e, 'rebate')}>
                    <div className="w-full h-full group-hover:bg-blue-500"></div>
                  </div>
                </th>
                <th 
                  className="py-3 px-4 text-right text-xs font-medium text-gray-700 uppercase tracking-wider relative"
                  style={{ width: `${columnWidths.netPrice}px` }}
                >
                  Net Price
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-500 group"
                       onMouseDown={(e) => handleMouseDown(e, 'netPrice')}>
                    <div className="w-full h-full group-hover:bg-blue-500"></div>
                  </div>
                </th>
                <th 
                  className="py-3 px-4 text-right text-xs font-medium text-gray-700 uppercase tracking-wider relative"
                  style={{ width: `${columnWidths.margin}px` }}
                >
                  Margin %
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-500 group"
                       onMouseDown={(e) => handleMouseDown(e, 'margin')}>
                    <div className="w-full h-full group-hover:bg-blue-500"></div>
                  </div>
                </th>
                <th 
                  className="py-3 px-4 text-right text-xs font-medium text-gray-700 uppercase tracking-wider relative"
                  style={{ width: `${columnWidths.totalValue}px` }}
                >
                  Total Value
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-500 group"
                       onMouseDown={(e) => handleMouseDown(e, 'totalValue')}>
                    <div className="w-full h-full group-hover:bg-blue-500"></div>
                  </div>
                </th>
                <th 
                  className="py-3 px-4 text-center text-xs font-medium text-gray-700 uppercase tracking-wider relative"
                  style={{ width: `${columnWidths.actions}px` }}
                >
                  Actions
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-500 group"
                       onMouseDown={(e) => handleMouseDown(e, 'actions')}>
                    <div className="w-full h-full group-hover:bg-blue-500"></div>
                  </div>
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {items.flatMap((item) => {
                const rows = [
                  <tr key={item.id} className="hover:bg-gray-50 group">
                    <td className="px-3 py-2" style={{ width: `${columnWidths.expand}px` }}>
                      <button
                        onClick={() => toggleAnalytics(item.id)}
                        className="text-gray-400 hover:text-gray-600"
                      >
                        {item.showAnalytics ? (
                          <ChevronDown className="w-4 h-4" />
                        ) : (
                          <ChevronRight className="w-4 h-4" />
                        )}
                      </button>
                    </td>
                    <td className="px-4 py-2" style={{ width: `${columnWidths.productName}px` }}>
                      <Input
                        value={item.productName}
                        onChange={(e) => updateItem(item.id, 'productName', e.target.value)}
                        className="border-0 bg-transparent focus-visible:ring-1 focus-visible:ring-blue-500 h-8"
                      />
                    </td>
                    <td className="px-4 py-2" style={{ width: `${columnWidths.sku}px` }}>
                      <Input
                        value={item.sku}
                        onChange={(e) => updateItem(item.id, 'sku', e.target.value)}
                        className="border-0 bg-transparent focus-visible:ring-1 focus-visible:ring-blue-500 h-8 text-sm"
                      />
                    </td>
                    <td className="px-4 py-2" style={{ width: `${columnWidths.quantity}px` }}>
                      <Input
                        type="number"
                        value={item.quantity}
                        onChange={(e) => updateItem(item.id, 'quantity', parseFloat(e.target.value) || 0)}
                        className="border-0 bg-transparent focus-visible:ring-1 focus-visible:ring-blue-500 h-8 text-right"
                      />
                    </td>
                    <td className="px-4 py-2" style={{ width: `${columnWidths.listPrice}px` }}>
                      <Input
                        type="number"
                        step="0.01"
                        value={item.listPrice}
                        onChange={(e) => updateItem(item.id, 'listPrice', parseFloat(e.target.value) || 0)}
                        className="border-0 bg-transparent focus-visible:ring-1 focus-visible:ring-blue-500 h-8 text-right"
                      />
                    </td>
                    <td className="px-4 py-2" style={{ width: `${columnWidths.cost}px` }}>
                      <Input
                        type="number"
                        step="0.01"
                        value={item.cost}
                        onChange={(e) => updateItem(item.id, 'cost', parseFloat(e.target.value) || 0)}
                        className="border-0 bg-transparent focus-visible:ring-1 focus-visible:ring-blue-500 h-8 text-right"
                      />
                    </td>
                    <td className="px-4 py-2" style={{ width: `${columnWidths.volumeDiscount}px` }}>
                      <Input
                        type="number"
                        step="0.1"
                        value={item.volumeDiscount}
                        onChange={(e) => updateItem(item.id, 'volumeDiscount', parseFloat(e.target.value) || 0)}
                        className="border-0 bg-transparent focus-visible:ring-1 focus-visible:ring-blue-500 h-8 text-right"
                      />
                    </td>
                    <td className="px-4 py-2" style={{ width: `${columnWidths.rebate}px` }}>
                      <Input
                        type="number"
                        step="0.01"
                        value={item.rebate}
                        onChange={(e) => updateItem(item.id, 'rebate', parseFloat(e.target.value) || 0)}
                        className="border-0 bg-transparent focus-visible:ring-1 focus-visible:ring-blue-500 h-8 text-right"
                      />
                    </td>
                    <td className="px-4 py-2 text-right text-sm font-medium text-gray-900 bg-blue-50" style={{ width: `${columnWidths.netPrice}px` }}>
                      {formatCurrency(item.netPrice)}
                    </td>
                    <td className="px-4 py-2 text-right text-sm font-semibold bg-purple-50" style={{ width: `${columnWidths.margin}px` }}>
                      <div className={`flex items-center justify-end gap-1 ${getMarginColor(item.margin)}`}>
                        {getMarginIcon(item.margin)}
                        {formatPercent(item.margin)}
                      </div>
                    </td>
                    <td className="px-4 py-2 text-right text-sm font-semibold text-gray-900 bg-green-50" style={{ width: `${columnWidths.totalValue}px` }}>
                      {formatCurrency(item.totalValue)}
                    </td>
                    <td className="px-4 py-2 text-center" style={{ width: `${columnWidths.actions}px` }}>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteItem(item.id)}
                        className="opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8 p-0"
                      >
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    </td>
                  </tr>
                ];
                
                if (item.showAnalytics) {
                  rows.push(
                    <tr key={`${item.id}-analytics`}>
                      <td colSpan={12} className="bg-gray-50 p-0">
                        <LineItemAnalytics item={item} />
                      </td>
                    </tr>
                  );
                }
                
                return rows;
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Footer with Add Button */}
      <div className="bg-white border-t border-gray-200 px-6 py-4">
        <Button onClick={addNewItem} variant="outline" className="gap-2">
          <Plus className="w-4 h-4" />
          Add Line Item
        </Button>
      </div>
    </div>
  );
}