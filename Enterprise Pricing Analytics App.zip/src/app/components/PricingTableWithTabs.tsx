import React, { useState, useRef, useEffect } from 'react';
import { Plus, Trash2, TrendingUp, TrendingDown, Minus, ChevronDown, ChevronRight, Download, Save, ArrowLeft, Check } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Textarea } from './ui/textarea';
import { LineItemAnalytics } from './LineItemAnalytics';
import { projectId, publicAnonKey } from '/utils/supabase/info';

export interface LineItem {
  id: string;
  productName: string;
  sku: string;
  quantity: number;
  listPrice: number;
  cost: number;
  volumeDiscount: number;
  rebate: number;
  netPrice: number;
  margin: number;
  totalValue: number;
  showAnalytics: boolean;
}

interface ColumnWidths {
  [key: string]: number;
}

interface PricingTableWithTabsProps {
  quoteId?: string;
  onBack: () => void;
}

export function PricingTableWithTabs({ quoteId, onBack }: PricingTableWithTabsProps) {
  const [currentQuoteId, setCurrentQuoteId] = useState(quoteId || '');
  const [description, setDescription] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  
  const [items, setItems] = useState<LineItem[]>([
    {
      id: '1',
      productName: 'Enterprise Software License',
      sku: 'ESL-2024-001',
      quantity: 100,
      listPrice: 299.99,
      cost: 150.00,
      volumeDiscount: 15,
      rebate: 500,
      netPrice: 0,
      margin: 0,
      totalValue: 0,
      showAnalytics: false,
    },
  ]);

  const [columnWidths, setColumnWidths] = useState<ColumnWidths>({
    expand: 50,
    productName: 250,
    sku: 150,
    quantity: 120,
    listPrice: 140,
    cost: 140,
    volumeDiscount: 140,
    rebate: 140,
    netPrice: 140,
    margin: 140,
    totalValue: 160,
    actions: 100,
  });

  // Header states
  const [productHierarchy, setProductHierarchy] = useState('');
  const [customer, setCustomer] = useState('');
  const [salesOrg, setSalesOrg] = useState('');
  const [region, setRegion] = useState('');
  const [country, setCountry] = useState('');
  const [currency, setCurrency] = useState('USD');
  const [priceList, setPriceList] = useState('');
  const [validityDate, setValidityDate] = useState('');
  const [paymentTerms, setPaymentTerms] = useState('');

  const [resizing, setResizing] = useState<{ column: string; startX: number; startWidth: number } | null>(null);
  const tableRef = useRef<HTMLDivElement>(null);

  // Load existing quote if quoteId is provided
  useEffect(() => {
    if (quoteId) {
      loadQuote(quoteId);
    }
  }, [quoteId]);

  const loadQuote = async (id: string) => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/quotes/${id}`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
          },
        }
      );

      const result = await response.json();
      if (result.success && result.data) {
        const quote = result.data;
        setCurrentQuoteId(quote.id);
        setDescription(quote.description || '');
        setCustomer(quote.customerName || '');
        setProductHierarchy(quote.productHierarchy || '');
        setSalesOrg(quote.salesOrg || '');
        setRegion(quote.region || '');
        setCountry(quote.country || '');
        setCurrency(quote.currency || 'USD');
        setPriceList(quote.priceList || '');
        setValidityDate(quote.validityDate || '');
        setPaymentTerms(quote.paymentTerms || '');
        setItems(quote.lineItems || []);
      }
    } catch (error) {
      console.error('Error loading quote:', error);
    }
  };

  const saveQuote = async () => {
    setIsSaving(true);
    setSaveSuccess(false);

    try {
      const quoteData = {
        id: currentQuoteId,
        description,
        customerName: customer,
        productHierarchy,
        salesOrg,
        region,
        country,
        currency,
        priceList,
        validityDate,
        paymentTerms,
        lineItems: items,
        totalValue: getTotalQuoteValue(),
        lineItemCount: items.length,
      };

      console.log('Saving quote:', quoteData);

      const url = currentQuoteId
        ? `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/quotes/${currentQuoteId}`
        : `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/quotes`;

      const method = currentQuoteId ? 'PUT' : 'POST';

      console.log('Request URL:', url);
      console.log('Method:', method);

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify(quoteData),
      });

      console.log('Response status:', response.status);
      const result = await response.json();
      console.log('Response result:', result);

      if (result.success) {
        setCurrentQuoteId(result.data.id);
        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 3000);
        alert('Quote saved successfully!');
      } else {
        alert(`Failed to save quote: ${result.error || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error saving quote:', error);
      alert(`Failed to save quote: ${error}`);
    } finally {
      setIsSaving(false);
    }
  };

  // Mouse resize handlers
  const handleMouseDown = (e: React.MouseEvent, column: string) => {
    e.preventDefault();
    setResizing({
      column,
      startX: e.clientX,
      startWidth: columnWidths[column],
    });
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!resizing) return;
      const diff = e.clientX - resizing.startX;
      const newWidth = Math.max(80, resizing.startWidth + diff);
      setColumnWidths((prev) => ({ ...prev, [resizing.column]: newWidth }));
    };

    const handleMouseUp = () => setResizing(null);

    if (resizing) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      document.body.style.cursor = 'col-resize';
      document.body.style.userSelect = 'none';
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
    };
  }, [resizing]);

  // Calculate derived values
  useEffect(() => {
    setItems((prevItems) =>
      prevItems.map((item) => {
        const discountedPrice = item.listPrice * (1 - item.volumeDiscount / 100);
        const totalBeforeRebate = discountedPrice * item.quantity;
        const totalAfterRebate = totalBeforeRebate - item.rebate;
        const netPrice = item.quantity > 0 ? totalAfterRebate / item.quantity : 0;
        const totalCost = item.cost * item.quantity;
        const margin = totalAfterRebate > 0 ? ((totalAfterRebate - totalCost) / totalAfterRebate) * 100 : 0;
        return { ...item, netPrice, margin, totalValue: totalAfterRebate };
      })
    );
  }, []);

  const addNewItem = () => {
    console.log('Adding new item. Current items count:', items.length);
    const newItem: LineItem = {
      id: Date.now().toString(),
      productName: 'New Product',
      sku: `SKU-${Date.now()}`,
      quantity: 1,
      listPrice: 0,
      cost: 0,
      volumeDiscount: 0,
      rebate: 0,
      netPrice: 0,
      margin: 0,
      totalValue: 0,
      showAnalytics: false,
    };
    console.log('New item:', newItem);
    const updatedItems = [...items, newItem];
    console.log('Updated items:', updatedItems);
    setItems(updatedItems);
  };

  const deleteItem = (id: string) => setItems(items.filter((item) => item.id !== id));

  const updateItem = (id: string, field: keyof LineItem, value: any) => {
    setItems((prevItems) =>
      prevItems.map((item) => {
        if (item.id !== id) return item;
        const updated = { ...item, [field]: value };
        const discountedPrice = updated.listPrice * (1 - updated.volumeDiscount / 100);
        const totalBeforeRebate = discountedPrice * updated.quantity;
        const totalAfterRebate = totalBeforeRebate - updated.rebate;
        const netPrice = updated.quantity > 0 ? totalAfterRebate / updated.quantity : 0;
        const totalCost = updated.cost * updated.quantity;
        const margin = totalAfterRebate > 0 ? ((totalAfterRebate - totalCost) / totalAfterRebate) * 100 : 0;
        return { ...updated, netPrice, margin, totalValue: totalAfterRebate };
      })
    );
  };

  const toggleAnalytics = (id: string) => {
    setItems((prevItems) =>
      prevItems.map((item) =>
        item.id === id ? { ...item, showAnalytics: !item.showAnalytics } : item
      )
    );
  };

  const getTotalQuoteValue = () => items.reduce((sum, item) => sum + item.totalValue, 0);

  const getAverageMargin = () => {
    const totalValue = getTotalQuoteValue();
    if (totalValue === 0) return 0;
    const weightedMarginSum = items.reduce((sum, item) => sum + (item.margin * item.totalValue), 0);
    return weightedMarginSum / totalValue;
  };

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 2 }).format(value);

  const formatPercent = (value: number) => `${value.toFixed(2)}%`;

  const getMarginColor = (margin: number) => {
    if (margin >= 40) return 'text-green-600';
    if (margin >= 25) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getMarginIcon = (margin: number) => {
    if (margin >= 40) return <TrendingUp className="w-4 h-4" />;
    if (margin >= 25) return <Minus className="w-4 h-4" />;
    return <TrendingDown className="w-4 h-4" />;
  };

  return (
    <div className="w-full h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={onBack} className="gap-2">
              <ArrowLeft className="w-4 h-4" />
              Back to Quotes
            </Button>
            <div>
              <h1 className="text-2xl font-semibold text-gray-900">
                {currentQuoteId || 'New Quote'}
              </h1>
              <p className="text-sm text-gray-500 mt-1">Total: {formatCurrency(getTotalQuoteValue())}</p>
            </div>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" className="gap-2">
              <Download className="w-4 h-4" />
              Export
            </Button>
            <Button onClick={saveQuote} disabled={isSaving} className="gap-2">
              {saveSuccess ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
              {isSaving ? 'Saving...' : saveSuccess ? 'Saved!' : 'Save Quote'}
            </Button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="header" className="flex-1 flex flex-col overflow-hidden">
        <div className="bg-white border-b border-gray-200 px-6">
          <TabsList className="h-12">
            <TabsTrigger value="header" className="text-sm">
              Quote Configuration
            </TabsTrigger>
            <TabsTrigger value="lineitems" className="text-sm">
              Line Items ({items.length})
            </TabsTrigger>
          </TabsList>
        </div>

        {/* Header Tab */}
        <TabsContent value="header" className="flex-1 overflow-auto mt-0">
          <div className="p-6">
            {/* Quote Description */}
            <div className="bg-white rounded-lg p-6 border border-gray-200 mb-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Quote Information</h2>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Enter quote description..."
                    className="min-h-[100px]"
                  />
                </div>
              </div>
            </div>

            {/* Summary Cards */}
            <div className="grid grid-cols-3 gap-4 mb-6">
              <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
                <div className="text-sm text-blue-700 mb-1">Total Quote Value</div>
                <div className="text-2xl font-semibold text-blue-900">{formatCurrency(getTotalQuoteValue())}</div>
              </div>
              <div className="bg-purple-50 rounded-lg p-4 border border-purple-200">
                <div className="text-sm text-purple-700 mb-1">Average Margin</div>
                <div className="text-2xl font-semibold text-purple-900">{formatPercent(getAverageMargin())}</div>
              </div>
              <div className="bg-gray-100 rounded-lg p-4 border border-gray-300">
                <div className="text-sm text-gray-700 mb-1">Total Line Items</div>
                <div className="text-2xl font-semibold text-gray-900">{items.length}</div>
              </div>
            </div>

            {/* Configuration */}
            <div className="bg-white rounded-lg p-6 border border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Configuration</h2>
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="product-hierarchy">Product Hierarchy</Label>
                  <Select value={productHierarchy} onValueChange={setProductHierarchy}>
                    <SelectTrigger id="product-hierarchy"><SelectValue placeholder="Select..." /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="software">Software Solutions</SelectItem>
                      <SelectItem value="hardware">Hardware Products</SelectItem>
                      <SelectItem value="services">Professional Services</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="customer">Customer</Label>
                  <Select value={customer} onValueChange={setCustomer}>
                    <SelectTrigger id="customer"><SelectValue placeholder="Select..." /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="acme-corp">Acme Corporation</SelectItem>
                      <SelectItem value="techstart-inc">TechStart Inc.</SelectItem>
                      <SelectItem value="global-systems">Global Systems Ltd.</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="sales-org">Sales Organization</Label>
                  <Select value={salesOrg} onValueChange={setSalesOrg}>
                    <SelectTrigger id="sales-org"><SelectValue placeholder="Select..." /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="us-east">US East</SelectItem>
                      <SelectItem value="us-west">US West</SelectItem>
                      <SelectItem value="emea">EMEA</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="region">Region</Label>
                  <Select value={region} onValueChange={setRegion}>
                    <SelectTrigger id="region"><SelectValue placeholder="Select..." /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="north-america">North America</SelectItem>
                      <SelectItem value="europe">Europe</SelectItem>
                      <SelectItem value="asia-pacific">Asia Pacific</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="country">Country</Label>
                  <Select value={country} onValueChange={setCountry}>
                    <SelectTrigger id="country"><SelectValue placeholder="Select..." /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="us">United States</SelectItem>
                      <SelectItem value="uk">United Kingdom</SelectItem>
                      <SelectItem value="de">Germany</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="currency">Currency</Label>
                  <Select value={currency} onValueChange={setCurrency}>
                    <SelectTrigger id="currency"><SelectValue placeholder="Select..." /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="USD">USD - US Dollar</SelectItem>
                      <SelectItem value="EUR">EUR - Euro</SelectItem>
                      <SelectItem value="GBP">GBP - British Pound</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="price-list">Price List</Label>
                  <Select value={priceList} onValueChange={setPriceList}>
                    <SelectTrigger id="price-list"><SelectValue placeholder="Select..." /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="standard">Standard Price List</SelectItem>
                      <SelectItem value="enterprise">Enterprise Price List</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="validity-date">Validity Date</Label>
                  <Input id="validity-date" type="date" value={validityDate} onChange={(e) => setValidityDate(e.target.value)} />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="payment-terms">Payment Terms</Label>
                  <Select value={paymentTerms} onValueChange={setPaymentTerms}>
                    <SelectTrigger id="payment-terms"><SelectValue placeholder="Select..." /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="net-30">Net 30</SelectItem>
                      <SelectItem value="net-60">Net 60</SelectItem>
                      <SelectItem value="net-90">Net 90</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>

        {/* Line Items Tab */}
        <TabsContent value="lineitems" className="flex-1 flex flex-col mt-0 overflow-hidden">
          <div className="flex-1 overflow-auto">
            <div className="inline-block min-w-full align-middle">
              <table className="min-w-full divide-y divide-gray-300 bg-white">
                <thead className="bg-gray-100 sticky top-0 z-10">
                  <tr>
                    <th className="py-3 px-3" style={{ width: `${columnWidths.expand}px` }}></th>
                    <th className="py-3 px-4 text-left text-xs font-medium text-gray-700 uppercase" style={{ width: `${columnWidths.productName}px` }}>Product Name</th>
                    <th className="py-3 px-4 text-left text-xs font-medium text-gray-700 uppercase" style={{ width: `${columnWidths.sku}px` }}>SKU</th>
                    <th className="py-3 px-4 text-right text-xs font-medium text-gray-700 uppercase" style={{ width: `${columnWidths.quantity}px` }}>Quantity</th>
                    <th className="py-3 px-4 text-right text-xs font-medium text-gray-700 uppercase" style={{ width: `${columnWidths.listPrice}px` }}>List Price</th>
                    <th className="py-3 px-4 text-right text-xs font-medium text-gray-700 uppercase" style={{ width: `${columnWidths.cost}px` }}>Cost</th>
                    <th className="py-3 px-4 text-right text-xs font-medium text-gray-700 uppercase" style={{ width: `${columnWidths.volumeDiscount}px` }}>Disc %</th>
                    <th className="py-3 px-4 text-right text-xs font-medium text-gray-700 uppercase" style={{ width: `${columnWidths.rebate}px` }}>Rebate</th>
                    <th className="py-3 px-4 text-right text-xs font-medium text-gray-700 uppercase" style={{ width: `${columnWidths.netPrice}px` }}>Net Price</th>
                    <th className="py-3 px-4 text-right text-xs font-medium text-gray-700 uppercase" style={{ width: `${columnWidths.margin}px` }}>Margin %</th>
                    <th className="py-3 px-4 text-right text-xs font-medium text-gray-700 uppercase" style={{ width: `${columnWidths.totalValue}px` }}>Total Value</th>
                    <th className="py-3 px-4 text-center text-xs font-medium text-gray-700 uppercase" style={{ width: `${columnWidths.actions}px` }}>Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {items.flatMap((item) => {
                    const rows = [
                      <tr key={item.id} className="hover:bg-gray-50 group">
                        <td className="px-3 py-2">
                          <button onClick={() => toggleAnalytics(item.id)} className="text-gray-400 hover:text-gray-600">
                            {item.showAnalytics ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                          </button>
                        </td>
                        <td className="px-4 py-2">
                          <Input value={item.productName} onChange={(e) => updateItem(item.id, 'productName', e.target.value)} className="border-0 bg-transparent h-8" />
                        </td>
                        <td className="px-4 py-2">
                          <Input value={item.sku} onChange={(e) => updateItem(item.id, 'sku', e.target.value)} className="border-0 bg-transparent h-8" />
                        </td>
                        <td className="px-4 py-2">
                          <Input type="number" value={item.quantity} onChange={(e) => updateItem(item.id, 'quantity', parseFloat(e.target.value) || 0)} className="border-0 bg-transparent h-8 text-right" />
                        </td>
                        <td className="px-4 py-2">
                          <Input type="number" step="0.01" value={item.listPrice} onChange={(e) => updateItem(item.id, 'listPrice', parseFloat(e.target.value) || 0)} className="border-0 bg-transparent h-8 text-right" />
                        </td>
                        <td className="px-4 py-2">
                          <Input type="number" step="0.01" value={item.cost} onChange={(e) => updateItem(item.id, 'cost', parseFloat(e.target.value) || 0)} className="border-0 bg-transparent h-8 text-right" />
                        </td>
                        <td className="px-4 py-2">
                          <Input type="number" step="0.1" value={item.volumeDiscount} onChange={(e) => updateItem(item.id, 'volumeDiscount', parseFloat(e.target.value) || 0)} className="border-0 bg-transparent h-8 text-right" />
                        </td>
                        <td className="px-4 py-2">
                          <Input type="number" step="0.01" value={item.rebate} onChange={(e) => updateItem(item.id, 'rebate', parseFloat(e.target.value) || 0)} className="border-0 bg-transparent h-8 text-right" />
                        </td>
                        <td className="px-4 py-2 text-right text-sm font-medium bg-blue-50">{formatCurrency(item.netPrice)}</td>
                        <td className="px-4 py-2 text-right text-sm font-semibold bg-purple-50">
                          <div className={`flex items-center justify-end gap-1 ${getMarginColor(item.margin)}`}>
                            {getMarginIcon(item.margin)}
                            {formatPercent(item.margin)}
                          </div>
                        </td>
                        <td className="px-4 py-2 text-right text-sm font-semibold bg-green-50">{formatCurrency(item.totalValue)}</td>
                        <td className="px-4 py-2 text-center">
                          <Button variant="ghost" size="sm" onClick={() => deleteItem(item.id)} className="opacity-0 group-hover:opacity-100 h-8 w-8 p-0">
                            <Trash2 className="w-4 h-4 text-red-500" />
                          </Button>
                        </td>
                      </tr>
                    ];
                    if (item.showAnalytics) {
                      rows.push(
                        <tr key={`${item.id}-analytics`}>
                          <td colSpan={12} className="bg-gray-50 p-0">
                            <LineItemAnalytics item={item} />
                          </td>
                        </tr>
                      );
                    }
                    return rows;
                  })}
                </tbody>
              </table>
            </div>
          </div>
          <div className="bg-white border-t border-gray-200 px-6 py-4">
            <Button onClick={addNewItem} variant="outline" className="gap-2">
              <Plus className="w-4 h-4" />
              Add Line Item
            </Button>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}