import React, { useState, useEffect } from 'react';
import {
  Sparkles, Plus, Edit, Trash2, Save, X, AlertCircle, CheckCircle,
  Database, Code, Brain, RefreshCw, Zap, FileText, List, Eye
} from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Input } from './ui/input';
import { Alert, AlertDescription } from './ui/alert';
import { projectId, publicAnonKey } from '/utils/supabase/info';

interface FieldLogicEditorProps {
  fieldName: string;
  fieldType: 'header' | 'line_item';
  onSave: (logic: FieldLogic) => void;
  onCancel: () => void;
  existingLogic?: FieldLogic;
}

interface FieldLogic {
  id: string;
  fieldName: string;
  fieldType: string;
  plainTextLogic: string;
  generatedCode: string;
  tableDependencies: string[];
  validationStatus: 'draft' | 'validating' | 'valid' | 'invalid';
  validationErrors: ValidationError[];
  version: number;
  createdAt: string;
  updatedAt: string;
}

interface ValidationError {
  type: 'missing_table' | 'missing_column' | 'syntax_error' | 'circular_dependency';
  message: string;
  suggestion: string;
  severity: 'error' | 'warning';
}

const EXAMPLES = [
  {
    title: 'Simple Table Lookup',
    logic: `Look up the "standard_price" from the "products" table where "product_sku" matches the current line item's SKU.`
  },
  {
    title: 'Volume Discount Calculation',
    logic: `Look up the "discount_percent" from the "volume_discounts" table where the "quantity" falls within the tier range. Then calculate: final_price = list_price * (1 - discount_percent / 100) * quantity.`
  },
  {
    title: 'Multiple Table Lookups',
    logic: `First, look up "customer_tier" from the "customers" table where "customer_id" matches header.customer_id. Then, look up "tier_discount" from the "discount_tiers" table where "tier" matches the customer_tier. Finally, calculate: discounted_price = base_price * (1 - tier_discount / 100).`
  },
  {
    title: 'Complex Margin Calculation',
    logic: `Look up "base_cost" from the "product_costs" table by product_sku. Look up "freight_rate" from the "freight_rates" table by region. Calculate total_cost = (base_cost * quantity) + (freight_rate * weight). Then calculate margin_percent = ((final_price - total_cost) / final_price) * 100.`
  },
  {
    title: 'Conditional Logic with Lookups',
    logic: `If customer_segment is "Enterprise", look up "enterprise_discount" from "segment_discounts" table. If customer_segment is "SMB", use a fixed 5% discount. Apply the discount to list_price and multiply by quantity.`
  }
];

export function FieldLogicEditor({ 
  fieldName, 
  fieldType, 
  onSave, 
  onCancel,
  existingLogic 
}: FieldLogicEditorProps) {
  const [plainTextLogic, setPlainTextLogic] = useState(existingLogic?.plainTextLogic || '');
  const [isValidating, setIsValidating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [validationResult, setValidationResult] = useState<{
    valid: boolean;
    errors: ValidationError[];
    generatedCode?: string;
    tableDependencies?: string[];
    explanation?: string;
  } | null>(null);
  const [availableTables, setAvailableTables] = useState<string[]>([]);
  const [showExamples, setShowExamples] = useState(false);

  useEffect(() => {
    loadAvailableTables();
  }, []);

  const loadAvailableTables = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/table-schemas`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
          },
        }
      );
      const data = await response.json();
      if (data.success && data.data) {
        const tableNames = Object.keys(data.data);
        setAvailableTables(tableNames);
      }
    } catch (error) {
      console.error('Error loading available tables:', error);
    }
  };

  const validateAndGenerate = async () => {
    if (!plainTextLogic.trim()) {
      alert('Please enter pricing logic first');
      return;
    }

    setIsValidating(true);
    setValidationResult(null);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/field-logic/validate`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({
            fieldName,
            fieldType,
            plainTextLogic,
            availableTables,
          }),
        }
      );

      const data = await response.json();
      setValidationResult(data);

    } catch (error) {
      console.error('Error validating logic:', error);
      setValidationResult({
        valid: false,
        errors: [{
          type: 'syntax_error',
          message: 'Failed to validate logic',
          suggestion: 'Please check your internet connection and try again',
          severity: 'error'
        }]
      });
    } finally {
      setIsValidating(false);
    }
  };

  const saveLogic = async () => {
    if (!validationResult?.valid) {
      alert('Please fix validation errors before saving');
      return;
    }

    setIsSaving(true);

    try {
      const logic: FieldLogic = {
        id: existingLogic?.id || `logic_${Date.now()}`,
        fieldName,
        fieldType,
        plainTextLogic,
        generatedCode: validationResult.generatedCode || '',
        tableDependencies: validationResult.tableDependencies || [],
        validationStatus: 'valid',
        validationErrors: [],
        version: (existingLogic?.version || 0) + 1,
        createdAt: existingLogic?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/field-logic/save`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({ logic }),
        }
      );

      const data = await response.json();
      if (data.success) {
        onSave(logic);
      } else {
        alert('Failed to save logic: ' + data.error);
      }
    } catch (error) {
      console.error('Error saving logic:', error);
      alert('Failed to save logic');
    } finally {
      setIsSaving(false);
    }
  };

  const insertExample = (example: typeof EXAMPLES[0]) => {
    setPlainTextLogic(example.logic);
    setShowExamples(false);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-5xl max-h-[90vh] overflow-auto bg-white">
        <div className="sticky top-0 bg-gradient-to-r from-purple-600 to-blue-600 text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-semibold">AI Field Logic Editor</h2>
              <p className="text-sm text-white/80">
                {fieldType === 'header' ? 'Header Field' : 'Line Item Field'}: {fieldName}
              </p>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={onCancel} className="text-white hover:bg-white/20">
            <X className="w-4 h-4" />
          </Button>
        </div>

        <div className="p-6 space-y-6">
          {/* Instructions */}
          <Alert className="border-blue-200 bg-blue-50">
            <Brain className="h-4 w-4 text-blue-600" />
            <AlertDescription className="text-blue-900 text-sm">
              <strong>Describe your pricing logic in plain English.</strong> The AI will validate table references, 
              generate executable code, and report any errors. You can reference tables, perform lookups, 
              and write complex formulas naturally.
            </AlertDescription>
          </Alert>

          {/* Available Tables */}
          {availableTables.length > 0 && (
            <Card className="p-4 bg-gray-50">
              <div className="flex items-center gap-2 mb-2">
                <Database className="w-4 h-4 text-gray-600" />
                <h3 className="text-sm font-semibold text-gray-900">Available Tables</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {availableTables.map(table => (
                  <span 
                    key={table}
                    className="px-2 py-1 bg-white border border-gray-200 rounded text-xs font-mono text-gray-700"
                  >
                    {table}
                  </span>
                ))}
              </div>
            </Card>
          )}

          {/* Examples Toggle */}
          <div className="flex justify-between items-center">
            <Label className="text-base font-semibold">Pricing Logic (Plain English)</Label>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowExamples(!showExamples)}
              className="gap-2"
            >
              <FileText className="w-4 h-4" />
              {showExamples ? 'Hide Examples' : 'Show Examples'}
            </Button>
          </div>

          {/* Examples */}
          {showExamples && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {EXAMPLES.map((example, idx) => (
                <Card 
                  key={idx}
                  className="p-3 cursor-pointer hover:shadow-md transition-shadow border-2 border-transparent hover:border-purple-200"
                  onClick={() => insertExample(example)}
                >
                  <h4 className="text-sm font-semibold text-gray-900 mb-1">{example.title}</h4>
                  <p className="text-xs text-gray-600 line-clamp-2">{example.logic}</p>
                  <div className="mt-2 text-xs text-purple-600 flex items-center gap-1">
                    <Plus className="w-3 h-3" />
                    Click to use this example
                  </div>
                </Card>
              ))}
            </div>
          )}

          {/* Logic Input */}
          <div>
            <Textarea
              value={plainTextLogic}
              onChange={(e) => setPlainTextLogic(e.target.value)}
              className="min-h-[200px] font-sans text-sm"
              placeholder="Example: Look up the 'discount_percent' from the 'volume_discounts' table where quantity is between 'min_qty' and 'max_qty'. Then calculate: final_price = list_price * (1 - discount_percent / 100) * quantity."
            />
            <p className="text-xs text-gray-500 mt-2">
              Tip: Be specific about table names, column names, and conditions. Use quotes around field names.
            </p>
          </div>

          {/* Validate Button */}
          <div className="flex gap-2">
            <Button
              onClick={validateAndGenerate}
              disabled={isValidating || !plainTextLogic.trim()}
              className="gap-2 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            >
              {isValidating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Validating with AI...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4" />
                  Validate & Generate Code
                </>
              )}
            </Button>

            {validationResult?.valid && (
              <Button
                onClick={saveLogic}
                disabled={isSaving}
                className="gap-2 bg-green-600 hover:bg-green-700"
              >
                {isSaving ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    Save Logic
                  </>
                )}
              </Button>
            )}
          </div>

          {/* Validation Results */}
          {validationResult && (
            <div className="space-y-4">
              {validationResult.valid ? (
                <>
                  <Alert className="border-green-200 bg-green-50">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <AlertDescription className="text-green-800">
                      <strong>Validation Successful!</strong> Your logic is valid and ready to save.
                    </AlertDescription>
                  </Alert>

                  {validationResult.explanation && (
                    <Card className="p-4 bg-blue-50 border-blue-200">
                      <h3 className="font-semibold text-blue-900 mb-2 flex items-center gap-2">
                        <Brain className="w-4 h-4" />
                        AI Understanding
                      </h3>
                      <p className="text-sm text-blue-800">{validationResult.explanation}</p>
                    </Card>
                  )}

                  {validationResult.tableDependencies && validationResult.tableDependencies.length > 0 && (
                    <Card className="p-4">
                      <h3 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                        <Database className="w-4 h-4" />
                        Table Dependencies
                      </h3>
                      <div className="flex flex-wrap gap-2">
                        {validationResult.tableDependencies.map(table => (
                          <span 
                            key={table}
                            className="px-2 py-1 bg-green-100 border border-green-300 rounded text-xs font-mono text-green-800 flex items-center gap-1"
                          >
                            <CheckCircle className="w-3 h-3" />
                            {table}
                          </span>
                        ))}
                      </div>
                    </Card>
                  )}

                  {validationResult.generatedCode && (
                    <Card className="p-4 bg-gray-900">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-semibold text-white flex items-center gap-2">
                          <Code className="w-4 h-4" />
                          Generated Executable Code
                        </h3>
                      </div>
                      <pre className="text-xs text-green-400 overflow-auto">
                        <code>{validationResult.generatedCode}</code>
                      </pre>
                    </Card>
                  )}
                </>
              ) : (
                <>
                  <Alert className="border-red-200 bg-red-50">
                    <AlertCircle className="h-4 w-4 text-red-600" />
                    <AlertDescription className="text-red-800">
                      <strong>Validation Failed!</strong> Please fix the errors below before saving.
                    </AlertDescription>
                  </Alert>

                  <div className="space-y-3">
                    {validationResult.errors.map((error, idx) => (
                      <Card 
                        key={idx}
                        className={`p-4 ${
                          error.severity === 'error' 
                            ? 'bg-red-50 border-red-200' 
                            : 'bg-amber-50 border-amber-200'
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <AlertCircle className={`w-5 h-5 flex-shrink-0 ${
                            error.severity === 'error' ? 'text-red-600' : 'text-amber-600'
                          }`} />
                          <div className="flex-1">
                            <h4 className={`font-semibold text-sm mb-1 ${
                              error.severity === 'error' ? 'text-red-900' : 'text-amber-900'
                            }`}>
                              {error.type.replace(/_/g, ' ').toUpperCase()}
                            </h4>
                            <p className={`text-sm mb-2 ${
                              error.severity === 'error' ? 'text-red-800' : 'text-amber-800'
                            }`}>
                              {error.message}
                            </p>
                            <div className={`text-xs p-2 rounded ${
                              error.severity === 'error' 
                                ? 'bg-red-100 text-red-700' 
                                : 'bg-amber-100 text-amber-700'
                            }`}>
                              <strong>Suggestion:</strong> {error.suggestion}
                            </div>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                </>
              )}
            </div>
          )}

          {/* Footer Actions */}
          <div className="flex justify-end gap-2 pt-4 border-t">
            <Button variant="outline" onClick={onCancel}>
              Cancel
            </Button>
            {validationResult?.valid && (
              <Button
                onClick={saveLogic}
                disabled={isSaving}
                className="gap-2"
              >
                {isSaving ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    Save & Apply
                  </>
                )}
              </Button>
            )}
          </div>
        </div>
      </Card>
    </div>
  );
}
