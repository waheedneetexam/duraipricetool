import React, { useState, useEffect } from 'react';
import {
  Sparkles, Plus, Edit, Trash2, ArrowLeft, Code, Database,
  CheckCircle, AlertCircle, Eye, History, RefreshCw
} from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { FieldLogicEditor } from './FieldLogicEditor';
import { projectId, publicAnonKey } from '/utils/supabase/info';

interface FieldLogicManagerProps {
  onBack: () => void;
}

interface FieldLogic {
  id: string;
  fieldName: string;
  fieldType: string;
  plainTextLogic: string;
  generatedCode: string;
  tableDependencies: string[];
  validationStatus: string;
  validationErrors: any[];
  version: number;
  createdAt: string;
  updatedAt: string;
}

export function FieldLogicManager({ onBack }: FieldLogicManagerProps) {
  const [logics, setLogics] = useState<FieldLogic[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingField, setEditingField] = useState<{
    name: string;
    type: 'header' | 'line_item';
    logic?: FieldLogic;
  } | null>(null);
  const [headerFields, setHeaderFields] = useState<any[]>([]);
  const [lineItemFields, setLineItemFields] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState('header');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      // Load existing logics
      const logicsResponse = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/field-logic/list`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
          },
        }
      );
      const logicsData = await logicsResponse.json();
      if (logicsData.success) {
        setLogics(logicsData.data || []);
      }

      // Load header fields
      const headerResponse = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/config/header-fields`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
          },
        }
      );
      const headerData = await headerResponse.json();
      if (headerData.success && headerData.data) {
        setHeaderFields(headerData.data);
      }

      // Load line item fields
      const lineItemResponse = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/config/line-item-fields`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
          },
        }
      );
      const lineItemData = await lineItemResponse.json();
      if (lineItemData.success && lineItemData.data) {
        setLineItemFields(lineItemData.data);
      }
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEditLogic = (fieldName: string, fieldType: 'header' | 'line_item') => {
    const existingLogic = logics.find(
      l => l.fieldName === fieldName && l.fieldType === fieldType
    );
    setEditingField({ name: fieldName, type: fieldType, logic: existingLogic });
  };

  const handleSaveLogic = async (logic: FieldLogic) => {
    // Update local state
    setLogics(prev => {
      const filtered = prev.filter(l => l.id !== logic.id);
      return [...filtered, logic];
    });
    setEditingField(null);
    await loadData();
  };

  const handleDeleteLogic = async (logicId: string) => {
    if (!confirm('Are you sure you want to delete this logic?')) return;

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-acb28b15/field-logic/delete`,
        {
          method: 'DELETE',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({ logicId }),
        }
      );

      const data = await response.json();
      if (data.success) {
        await loadData();
      } else {
        alert('Failed to delete logic: ' + data.error);
      }
    } catch (error) {
      console.error('Error deleting logic:', error);
      alert('Failed to delete logic');
    }
  };

  const getLogicForField = (fieldName: string, fieldType: string) => {
    return logics.find(l => l.fieldName === fieldName && l.fieldType === fieldType);
  };

  const renderFieldCard = (field: any, fieldType: 'header' | 'line_item') => {
    const logic = getLogicForField(field.name || field.id, fieldType);
    const hasLogic = !!logic;

    return (
      <Card 
        key={field.id || field.name}
        className={`p-4 ${hasLogic ? 'border-2 border-purple-200 bg-purple-50' : ''}`}
      >
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <h3 className="font-semibold text-gray-900">
                {field.displayName || field.name}
              </h3>
              <span className="text-xs px-2 py-1 bg-gray-100 text-gray-600 rounded">
                {field.type}
              </span>
              {hasLogic && (
                <span className="text-xs px-2 py-1 bg-purple-100 text-purple-700 rounded flex items-center gap-1">
                  <Sparkles className="w-3 h-3" />
                  AI Logic
                </span>
              )}
            </div>
            {field.description && (
              <p className="text-xs text-gray-600">{field.description}</p>
            )}
          </div>
          <div className="flex gap-1">
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleEditLogic(field.name || field.id, fieldType)}
              className="gap-1"
            >
              {hasLogic ? <Edit className="w-3 h-3" /> : <Plus className="w-3 h-3" />}
              {hasLogic ? 'Edit' : 'Add'}
            </Button>
            {hasLogic && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleDeleteLogic(logic.id)}
                className="text-red-600 hover:text-red-700 hover:bg-red-50"
              >
                <Trash2 className="w-3 h-3" />
              </Button>
            )}
          </div>
        </div>

        {hasLogic && (
          <div className="space-y-2">
            <div className="p-3 bg-white rounded border border-purple-200">
              <div className="flex items-center gap-2 mb-2">
                <Code className="w-3 h-3 text-gray-600" />
                <span className="text-xs font-semibold text-gray-700">Logic Description</span>
              </div>
              <p className="text-xs text-gray-600 line-clamp-2">
                {logic.plainTextLogic}
              </p>
            </div>

            {logic.tableDependencies && logic.tableDependencies.length > 0 && (
              <div className="flex items-center gap-2 flex-wrap">
                <Database className="w-3 h-3 text-gray-500" />
                <span className="text-xs text-gray-500">Tables:</span>
                {logic.tableDependencies.map(table => (
                  <span 
                    key={table}
                    className="text-xs px-2 py-0.5 bg-blue-100 text-blue-700 rounded font-mono"
                  >
                    {table}
                  </span>
                ))}
              </div>
            )}

            <div className="flex items-center justify-between text-xs text-gray-500">
              <span className="flex items-center gap-1">
                <History className="w-3 h-3" />
                Version {logic.version}
              </span>
              <span>Updated: {new Date(logic.updatedAt).toLocaleDateString()}</span>
            </div>
          </div>
        )}
      </Card>
    );
  };

  if (loading) {
    return (
      <div className="w-full h-screen flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 animate-spin text-purple-600 mx-auto mb-2" />
          <p className="text-gray-600">Loading field configurations...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={onBack} className="gap-2">
              <ArrowLeft className="w-4 h-4" />
              Back
            </Button>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-blue-600 rounded-xl flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                  Field Logic Manager
                </h1>
                <p className="text-sm text-gray-500 mt-1">
                  Define AI-powered pricing logic for individual fields
                </p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-600">
              {logics.length} field{logics.length !== 1 ? 's' : ''} with logic
            </span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto p-6">
        <Alert className="mb-6 border-purple-200 bg-gradient-to-r from-purple-50 to-blue-50">
          <Sparkles className="h-4 w-4 text-purple-600" />
          <AlertDescription className="text-gray-800">
            <strong>Define pricing logic in plain English for each field.</strong> The AI will validate table 
            references, generate executable code, and ensure all dependencies exist before creating permanent logic.
          </AlertDescription>
        </Alert>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full max-w-md grid-cols-2 mb-6">
            <TabsTrigger value="header" className="gap-2">
              Header Fields ({headerFields.length})
            </TabsTrigger>
            <TabsTrigger value="line_item" className="gap-2">
              Line Item Fields ({lineItemFields.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="header" className="space-y-4">
            {headerFields.length === 0 ? (
              <Card className="p-12 text-center">
                <AlertCircle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <h3 className="text-lg font-medium text-gray-500 mb-2">No Header Fields</h3>
                <p className="text-sm text-gray-400">
                  Configure header fields in the AI Pricing Engine first
                </p>
              </Card>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {headerFields.map(field => renderFieldCard(field, 'header'))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="line_item" className="space-y-4">
            {lineItemFields.length === 0 ? (
              <Card className="p-12 text-center">
                <AlertCircle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <h3 className="text-lg font-medium text-gray-500 mb-2">No Line Item Fields</h3>
                <p className="text-sm text-gray-400">
                  Configure line item fields in the Line Item Configurator first
                </p>
              </Card>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {lineItemFields.map(field => renderFieldCard(field, 'line_item'))}
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* Summary Statistics */}
        <Card className="mt-6 p-6 bg-gradient-to-br from-purple-50 to-blue-50">
          <h3 className="font-semibold text-gray-900 mb-4">Logic Summary</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <CheckCircle className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900">{logics.length}</div>
                <div className="text-xs text-gray-600">Total Logic Rules</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <Database className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900">
                  {new Set(logics.flatMap(l => l.tableDependencies || [])).size}
                </div>
                <div className="text-xs text-gray-600">Tables Referenced</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900">
                  {logics.filter(l => l.validationStatus === 'valid').length}
                </div>
                <div className="text-xs text-gray-600">Validated Rules</div>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Editor Modal */}
      {editingField && (
        <FieldLogicEditor
          fieldName={editingField.name}
          fieldType={editingField.type}
          existingLogic={editingField.logic}
          onSave={handleSaveLogic}
          onCancel={() => setEditingField(null)}
        />
      )}
    </div>
  );
}
