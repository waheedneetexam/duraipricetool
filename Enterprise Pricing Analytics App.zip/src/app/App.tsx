import { useState } from 'react';
import { PricingTable } from './components/PricingTable';
import { PricingTableWithTabs } from './components/PricingTableWithTabs';
import { QuoteList } from './components/QuoteList';
import { AdminScreen } from './components/AdminScreen';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Button } from './components/ui/button';
import { Settings, Table, FileText } from 'lucide-react';
import './utils/console-filter';

type View = 'quotes' | 'pricing' | 'admin';

export default function App() {
  const [currentView, setCurrentView] = useState<View>('quotes');
  const [editingQuoteId, setEditingQuoteId] = useState<string | undefined>(undefined);

  const handleCreateNewQuote = () => {
    setEditingQuoteId(undefined);
    setCurrentView('pricing');
  };

  const handleEditQuote = (quoteId: string) => {
    setEditingQuoteId(quoteId);
    setCurrentView('pricing');
  };

  const handleBackToQuotes = () => {
    setEditingQuoteId(undefined);
    setCurrentView('quotes');
  };

  return (
    <ErrorBoundary>
      <div className="w-full h-screen flex flex-col">
        {/* Navigation */}
        <div className="bg-gray-600 text-white px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-lg font-semibold">Enterprise Pricing System</h1>
            {currentView !== 'pricing' && (
              <div className="flex gap-2">
                <Button
                  variant={currentView === 'quotes' ? 'secondary' : 'ghost'}
                  size="sm"
                  onClick={() => setCurrentView('quotes')}
                  className={currentView === 'quotes' ? '' : 'text-gray-300 hover:text-white'}
                >
                  <FileText className="w-4 h-4 mr-2" />
                  Quotes
                </Button>
                <Button
                  variant={currentView === 'admin' ? 'secondary' : 'ghost'}
                  size="sm"
                  onClick={() => setCurrentView('admin')}
                  className={currentView === 'admin' ? '' : 'text-gray-300 hover:text-white'}
                >
                  <Settings className="w-4 h-4 mr-2" />
                  Admin
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-hidden">
          {currentView === 'quotes' && (
            <QuoteList 
              onCreateNew={handleCreateNewQuote} 
              onEditQuote={handleEditQuote}
            />
          )}
          {currentView === 'pricing' && (
            <PricingTableWithTabs 
              quoteId={editingQuoteId}
              onBack={handleBackToQuotes}
            />
          )}
          {currentView === 'admin' && <AdminScreen />}
        </div>
      </div>
    </ErrorBoundary>
  );
}